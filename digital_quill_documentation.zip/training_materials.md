# Digital Quill Publishing Training Materials

## Table of Contents
1. Introduction to Training
2. Getting Started with AI in Publishing
3. Understanding LangChain Basics
4. Setting Up Your Development Environment
5. Building Your First AI Agent
6. Working with Manuscripts
7. Creating Web Interfaces
8. Testing and Quality Assurance
9. Deployment Basics
10. Exercises and Practice Projects

## 1. Introduction to Training

### 1.1 How to Use These Training Materials
This training guide is designed to complement the Implementation Guide for Digital Quill Publishing. While the Implementation Guide provides comprehensive technical details, these training materials focus on practical learning with step-by-step tutorials and exercises.

### 1.2 Training Approach
We recommend following these materials in sequence, completing each exercise before moving to the next section. Each module builds upon skills learned in previous sections.

### 1.3 Prerequisites
- Basic computer literacy
- Familiarity with using command line interfaces
- Basic understanding of programming concepts (variables, functions, etc.)
- No prior experience with AI or publishing systems is required

## 2. Getting Started with AI in Publishing

### 2.1 Understanding AI in the Publishing Context

#### What is AI in Publishing?
AI in publishing refers to the use of artificial intelligence technologies to automate and enhance various aspects of the publishing process. At Digital Quill Publishing, we use AI to perform roles traditionally handled by human editors, marketers, and production staff.

#### Key Benefits of AI in Publishing:
- **Efficiency**: Processes manuscripts faster than traditional methods
- **Consistency**: Applies the same high standards to every manuscript
- **Scalability**: Handles multiple manuscripts simultaneously
- **Data-driven insights**: Provides objective analysis based on market trends
- **Accessibility**: Makes professional publishing expertise available to more authors

#### Exercise 2.1: Identifying AI Opportunities
1. List three tasks in the traditional publishing process that are time-consuming
2. For each task, describe how AI might help streamline the process
3. Consider potential limitations of AI in these contexts

### 2.2 The Publishing Process Overview

#### Traditional Publishing Workflow:
1. **Acquisition**: Editors review submissions and decide which to publish
2. **Development**: Editors work with authors to improve manuscripts
3. **Production**: Text is prepared for publication (copyediting, design, etc.)
4. **Marketing**: Creating and implementing strategies to promote the book
5. **Distribution**: Getting the book to retailers and readers

#### Digital Quill's AI-Enhanced Workflow:
1. **AI Acquisition**: Automated evaluation of commercial potential
2. **AI Development**: Structured feedback on plot, characters, and writing
3. **AI Production**: Automated formatting and consistency checking
4. **AI Marketing**: Data-driven marketing strategy generation
5. **Author Portal**: Central interface for author-AI collaboration

#### Exercise 2.2: Mapping the Publishing Process
1. Create a flowchart of the traditional publishing process
2. Create a parallel flowchart showing Digital Quill's AI-enhanced process
3. Identify key differences and similarities between the two approaches

### 2.3 Introduction to AI Concepts

#### Key AI Terminology:
- **Large Language Models (LLMs)**: AI systems trained on vast text data
- **Prompt Engineering**: Crafting effective instructions for AI models
- **Vector Embeddings**: Numerical representations of text that capture meaning
- **Semantic Search**: Finding information based on meaning rather than keywords
- **Chain of Thought**: Breaking complex reasoning into sequential steps

#### How LLMs Work (Simplified):
1. Text is converted into numerical representations (tokens)
2. The model processes these tokens using patterns learned during training
3. The model generates new tokens based on statistical predictions
4. These tokens are converted back into human-readable text

#### Exercise 2.3: Basic Prompt Engineering
1. Write three different prompts asking for a manuscript evaluation
2. For each prompt, identify specific instructions and constraints
3. Discuss how different phrasings might lead to different AI responses

## 3. Understanding LangChain Basics

### 3.1 What is LangChain?

#### LangChain Overview:
LangChain is a framework for developing applications powered by language models. It provides tools to:
- Connect LLMs with other data sources and applications
- Create chains of operations for complex tasks
- Build agents that can use tools and make decisions
- Process and manage documents effectively

#### Key Components:
- **LLMs**: Interface with language models (OpenAI, Anthropic, etc.)
- **Prompts**: Templates for generating effective prompts
- **Chains**: Sequences of operations (LLM calls, data processing, etc.)
- **Agents**: Autonomous systems that use tools to accomplish tasks
- **Memory**: Systems for maintaining context in conversations
- **Document loaders**: Tools for ingesting various document formats

#### Exercise 3.1: Exploring LangChain Components
1. Visit the LangChain documentation website
2. Identify three components that would be useful for manuscript evaluation
3. For each component, write a brief description of how it would be used

### 3.2 LangChain for Document Processing

#### Document Handling in LangChain:
1. **Loading**: Converting files (PDF, DOCX, etc.) into document objects
2. **Splitting**: Breaking documents into manageable chunks
3. **Embedding**: Converting text chunks into vector representations
4. **Storing**: Saving vectors in a database for retrieval
5. **Retrieving**: Finding relevant information based on queries

#### Example: Processing a Manuscript
```python
# Load a manuscript
from langchain.document_loaders import PyPDFLoader
loader = PyPDFLoader("manuscript.pdf")
documents = loader.load()

# Split into chunks
from langchain.text_splitter import RecursiveCharacterTextSplitter
text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=100)
chunks = text_splitter.split_documents(documents)

# Create embeddings
from langchain.embeddings import OpenAIEmbeddings
embeddings = OpenAIEmbeddings()
document_embeddings = embeddings.embed_documents([chunk.page_content for chunk in chunks])
```

#### Exercise 3.2: Document Processing Practice
1. Create a simple text file with several paragraphs
2. Write pseudocode for loading and splitting this document
3. Describe how you would retrieve information about a specific character or plot point

### 3.3 Building Chains in LangChain

#### Chain Basics:
Chains connect multiple components to perform complex tasks. A basic chain might:
1. Take user input
2. Process it using a prompt template
3. Send the formatted prompt to an LLM
4. Return the LLM's response

#### Example: Simple Evaluation Chain
```python
from langchain.chains import LLMChain
from langchain.llms import OpenAI
from langchain.prompts import PromptTemplate

# Create a prompt template
template = """
Evaluate the following manuscript excerpt:
{manuscript_text}

Provide feedback on:
1. Writing quality
2. Character development
3. Plot engagement
"""

prompt = PromptTemplate(
    input_variables=["manuscript_text"],
    template=template
)

# Create an LLM
llm = OpenAI(temperature=0.3)

# Create a chain
evaluation_chain = LLMChain(llm=llm, prompt=prompt)

# Run the chain
result = evaluation_chain.run(manuscript_text="Once upon a time...")
print(result)
```

#### Exercise 3.3: Chain Design
1. Design a chain for analyzing dialogue in a manuscript
2. List the input variables needed for your chain
3. Write a prompt template that would produce useful dialogue analysis
4. Describe how you would use the output of this chain

## 4. Setting Up Your Development Environment

### 4.1 Step-by-Step Environment Setup

#### Installing Python:
1. **Windows**:
   - Download the installer from python.org
   - Run the installer, checking "Add Python to PATH"
   - Open Command Prompt and type `python --version` to verify

2. **macOS**:
   - Install Homebrew if not already installed: `/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"`
   - Install Python: `brew install python`
   - Verify installation: `python3 --version`

3. **Linux**:
   - Most distributions come with Python pre-installed
   - If needed: `sudo apt install python3 python3-pip` (Ubuntu/Debian)
   - Verify installation: `python3 --version`

#### Setting Up a Virtual Environment:
```bash
# Navigate to your project folder
cd my_project

# Create a virtual environment
python -m venv venv

# Activate the virtual environment
# On Windows:
venv\Scripts\activate
# On macOS/Linux:
source venv/bin/activate

# Your command prompt should now show (venv) at the beginning
```

#### Installing Required Packages:
```bash
# Install LangChain and related packages
pip install langchain openai chromadb tiktoken

# Install document processing packages
pip install unstructured pdf2image pytesseract

# Install web framework
pip install flask flask-wtf
```

#### Exercise 4.1: Environment Setup
1. Set up a Python virtual environment on your computer
2. Install the required packages
3. Create a simple Python script that prints "Hello, Digital Quill!"
4. Run the script to verify your environment is working

### 4.2 Setting Up API Access

#### Getting an OpenAI API Key:
1. Create an account at https://platform.openai.com/
2. Navigate to API Keys section
3. Create a new secret key
4. Copy the key (you won't be able to see it again)

#### Setting Up Environment Variables:
1. Create a file named `.env` in your project directory
2. Add your API key:
   ```
   OPENAI_API_KEY=your_key_here
   ```
3. Create a Python script to test the connection:
   ```python
   from dotenv import load_dotenv
   import os
   import openai
   
   # Load environment variables
   load_dotenv()
   
   # Configure OpenAI
   openai.api_key = os.getenv("OPENAI_API_KEY")
   
   # Test connection
   response = openai.ChatCompletion.create(
       model="gpt-3.5-turbo",
       messages=[{"role": "user", "content": "Hello, are you working?"}]
   )
   
   print(response.choices[0].message.content)
   ```

#### Exercise 4.2: API Connection
1. Sign up for an OpenAI account (or use a test account provided by your organization)
2. Set up your API key in a .env file
3. Run the test script to verify your connection
4. Modify the script to ask a publishing-related question

### 4.3 Setting Up Flowise (Visual Interface)

#### Installing Flowise:
```bash
# Install Node.js if not already installed
# Then install Flowise
npm install -g flowise

# Start Flowise
npx flowise start
```

#### Accessing the Interface:
1. Open your browser and navigate to http://localhost:3000
2. You should see the Flowise visual interface
3. Configure your API keys in the settings

#### Creating Your First Flow:
1. Click "Create New Flow"
2. Add an "Input" node
3. Add an "LLM" node
4. Connect the nodes
5. Configure the LLM node with your API key
6. Test the flow with a simple prompt

#### Exercise 4.3: Flowise Exploration
1. Install and start Flowise
2. Create a simple flow that takes text input and generates a summary
3. Test the flow with a paragraph from a book
4. Export your flow as JSON for future reference

## 5. Building Your First AI Agent

### 5.1 Creating the Acquisition Editor AI

#### Understanding the Acquisition Editor Role:
The Acquisition Editor AI evaluates manuscripts to determine their publishing potential, considering:
- Writing quality
- Plot and structure
- Character development
- Market potential
- Target audience

#### Step 1: Define Evaluation Criteria
```python
# evaluation_criteria.py

ACQUISITION_CRITERIA = """
Evaluate this manuscript section based on the following criteria:
1. Writing Quality (1-10): Assess prose, dialogue, and narrative voice
2. Plot and Structure (1-10): Evaluate story structure and pacing
3. Character Development (1-10): Assess depth and believability of characters
4. Market Potential (1-10): Consider commercial viability and target audience
5. Uniqueness (1-10): Identify original elements and unique selling points

For each criterion, provide a score and brief justification.
Then provide an overall recommendation: Reject, Revise and Resubmit, or Accept.
"""
```

#### Step 2: Create the Evaluation Chain
```python
# acquisition_chain.py
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from langchain.llms import OpenAI

def create_evaluation_chain():
    """Create a chain for manuscript evaluation"""
    llm = OpenAI(temperature=0.2)
    
    prompt = PromptTemplate(
        input_variables=["manuscript_chunk", "criteria"],
        template="""
        You are an experienced Acquisition Editor at a publishing house.
        
        Please review this manuscript section:
        
        {manuscript_chunk}
        
        {criteria}
        """
    )
    
    return LLMChain(llm=llm, prompt=prompt)
```

#### Step 3: Process Manuscript Chunks
```python
# manuscript_evaluation.py
from acquisition_chain import create_evaluation_chain

def evaluate_manuscript_chunk(chunk, criteria):
    """Evaluate a single chunk of a manuscript"""
    evaluation_chain = create_evaluation_chain()
    result = evaluation_chain.run(
        manuscript_chunk=chunk,
        criteria=criteria
    )
    return result

def evaluate_manuscript(chunks, criteria):
    """Evaluate all chunks of a manuscript"""
    evaluations = []
    
    for i, chunk in enumerate(chunks):
        print(f"Evaluating chunk {i+1}/{len(chunks)}...")
        result = evaluate_manuscript_chunk(chunk.page_content, criteria)
        evaluations.append(result)
        
    return evaluations
```

#### Exercise 5.1: Building an Acquisition Evaluator
1. Create a Python script that implements the evaluation chain
2. Write a simple test manuscript excerpt (2-3 paragraphs)
3. Run your evaluator on the excerpt
4. Analyze the results and suggest improvements to your evaluation criteria

### 5.2 Creating the Developmental Editor AI

#### Understanding the Developmental Editor Role:
The Developmental Editor AI provides substantive feedback on manuscripts, focusing on:
- Plot structure and pacing
- Character development and arcs
- Thematic elements
- Overall narrative effectiveness

#### Step 1: Create Specialized Analysis Functions
```python
# plot_analysis.py
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from langchain.llms import OpenAI

def analyze_plot_structure(text):
    """Analyze the plot structure of a manuscript"""
    llm = OpenAI(temperature=0.2)
    
    prompt = PromptTemplate(
        input_variables=["text"],
        template="""
        Analyze the plot structure in this manuscript excerpt:
        
        {text}
        
        Provide analysis of:
        1. Key plot points identified
        2. Pacing and tension
        3. Narrative arc
        4. Any structural issues
        5. Recommendations for improvement
        
        Be specific and constructive in your feedback.
        """
    )
    
    chain = LLMChain(llm=llm, prompt=prompt)
    return chain.run(text=text)
```

#### Step 2: Create Character Analysis Function
```python
# character_analysis.py
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from langchain.llms import OpenAI

def analyze_characters(text):
    """Analyze character development in a manuscript"""
    llm = OpenAI(temperature=0.2)
    
    prompt = PromptTemplate(
        input_variables=["text"],
        template="""
        Analyze the characters in this manuscript excerpt:
        
        {text}
        
        For each character mentioned, provide:
        1. Character name and role
        2. Personality traits shown
        3. Development and arc (if any)
        4. Strengths in characterization
        5. Areas for improvement
        
        Be specific and constructive in your feedback.
        """
    )
    
    chain = LLMChain(llm=llm, prompt=prompt)
    return chain.run(text=text)
```

#### Step 3: Generate Editorial Letter
```python
# editorial_letter.py
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from langchain.llms import OpenAI

def generate_editorial_letter(plot_analysis, character_analysis, title, author):
    """Generate a comprehensive editorial letter"""
    llm = OpenAI(temperature=0.4)
    
    prompt = PromptTemplate(
        input_variables=["plot_analysis", "character_analysis", "title", "author"],
        template="""
        You are a Developmental Editor writing a letter to an author about their manuscript.
        
        Manuscript: "{title}" by {author}
        
        Plot Analysis:
        {plot_analysis}
        
        Character Analysis:
        {character_analysis}
        
        Write a comprehensive, encouraging editorial letter that:
        1. Opens with a positive and personalized greeting
        2. Provides an overview of the manuscript's strengths
        3. Addresses the major areas for improvement (plot, characters)
        4. Offers specific, actionable suggestions for revision
        5. Concludes with encouragement and next steps
        
        The tone should be professional but supportive. Be specific with examples.
        Format the letter professionally with appropriate sections and paragraphs.
        """
    )
    
    chain = LLMChain(llm=llm, prompt=prompt)
    letter = chain.run(
        plot_analysis=plot_analysis,
        character_analysis=character_analysis,
        title=title,
        author=author
    )
    
    return letter
```

#### Exercise 5.2: Building a Developmental Editor
1. Create Python scripts implementing the plot and character analysis functions
2. Write a test manuscript excerpt (1-2 pages)
3. Generate analyses for your excerpt
4. Use these analyses to create an editorial letter
5. Review the letter for helpfulness and constructive feedback

## 6. Working with Manuscripts

### 6.1 Manuscript Processing Fundamentals

#### Loading Different File Formats:
```python
# manuscript_loader.py
from langchain.document_loaders import TextLoader, PyPDFLoader, Docx2txtLoader

def load_manuscript(file_path):
    """Load manuscript from various file formats"""
    if file_path.endswith('.txt'):
        loader = TextLoader(file_path)
    elif file_path.endswith('.pdf'):
        loader = PyPDFLoader(file_path)
    elif file_path.endswith('.docx'):
        loader = Docx2txtLoader(file_path)
    else:
        raise ValueError(f"Unsupported file format: {file_path}")
        
    return loader.load()
```

#### Splitting Manuscripts:
```python
# text_processing.py
from langchain.text_splitter import RecursiveCharacterTextSplitter

def split_manuscript(documents, chunk_size=1000, chunk_overlap=100):
    """Split manuscript into manageable chunks"""
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap
    )
    return text_splitter.split_documents(documents)
```

#### Exercise 6.1: Manuscript Processing
1. Create a small sample manuscript in TXT, DOCX, and PDF formats
2. Write a script that loads each format and prints the first 100 characters
3. Implement the splitting function and print the number of chunks created
4. Experiment with different chunk sizes and overlaps

### 6.2 Advanced Manuscript Analysis

#### Extracting Key Elements:
```python
# manuscript_elements.py
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from langchain.llms import OpenAI

def extract_key_elements(text):
    """Extract key narrative elements from text"""
    llm = OpenAI(temperature=0.2)
    
    prompt = PromptTemplate(
        input_variables=["text"],
        template="""
        Extract the following elements from this manuscript excerpt:
        
        {text}
        
        1. Setting (time and place)
        2. Main characters mentioned
        3. Key events or plot points
        4. Conflicts or tensions
        5. Themes or motifs
        
        Format your response as a structured list with these categories.
        """
    )
    
    chain = LLMChain(llm=llm, prompt=prompt)
    return chain.run(text=text)
```

#### Genre Classification:
```python
# genre_classification.py
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from langchain.llms import OpenAI

def classify_genre(text):
    """Identify the likely genre of a manuscript"""
    llm = OpenAI(temperature=0.1)
    
    prompt = PromptTemplate(
        input_variables=["text"],
        template="""
        Based on this manuscript excerpt, identify the most likely genre and subgenre:
        
        {text}
        
        Provide:
        1. Primary genre
        2. Subgenre (if applicable)
        3. Confidence level (high, medium, low)
        4. Evidence from the text supporting this classification
        5. Potential comparable titles in this genre
        
        Format your response as a structured analysis.
        """
    )
    
    chain = LLMChain(llm=llm, prompt=prompt)
    return chain.run(text=text)
```

#### Exercise 6.2: Advanced Analysis
1. Create a script that combines element extraction and genre classification
2. Test it on excerpts from different genres (mystery, romance, fantasy, etc.)
3. Evaluate the accuracy of the genre classification
4. Suggest improvements to make the analysis more accurate

### 6.3 Creating a Complete Manuscript Pipeline

#### Building an End-to-End Pipeline:
```python
# manuscript_pipeline.py
from manuscript_loader import load_manuscript
from text_processing import split_manuscript
from manuscript_elements import extract_key_elements
from genre_classification import classify_genre
from acquisition_evaluation import evaluate_manuscript
from evaluation_criteria import ACQUISITION_CRITERIA

def process_manuscript(file_path, metadata):
    """Process a manuscript through the complete pipeline"""
    results = {}
    
    # Step 1: Load the manuscript
    print("Loading manuscript...")
    documents = load_manuscript(file_path)
    
    # Step 2: Split into chunks
    print("Splitting manuscript...")
    chunks = split_manuscript(documents)
    
    # Step 3: Extract key elements from first chunk
    print("Extracting key elements...")
    first_chunk = chunks[0].page_content
    results["key_elements"] = extract_key_elements(first_chunk)
    
    # Step 4: Classify genre
    print("Classifying genre...")
    results["genre_analysis"] = classify_genre(first_chunk)
    
    # Step 5: Evaluate manuscript
    print("Evaluating manuscript...")
    evaluations = evaluate_manuscript(chunks, ACQUISITION_CRITERIA)
    results["evaluations"] = evaluations
    
    # Step 6: Generate final report
    print("Generating report...")
    # (Report generation code would go here)
    
    return results
```

#### Exercise 6.3: Complete Pipeline
1. Implement the complete manuscript pipeline
2. Create a test manuscript (or use a public domain short story)
3. Process the manuscript through your pipeline
4. Create a simple function to display the results in a readable format
5. Identify any bottlenecks or areas for improvement in your pipeline

## 7. Creating Web Interfaces

### 7.1 Building a Basic Flask Application

#### Setting Up Flask:
```python
# app.py
from flask import Flask, render_template, request, redirect, url_for, flash
from flask_login import LoginManager, login_user, logout_user, login_required, current_user

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key'  # Change this in production!

login_manager = LoginManager(app)
login_manager.login_view = 'login'

# Mock user database (replace with real database in production)
users = {}

@app.route('/')
def home():
    return render_template('home.html')

if __name__ == '__main__':
    app.run(debug=True)
```

#### Creating Templates:
```html
<!-- templates/base.html -->
<!DOCTYPE html>
<html>
<head>
    <title>Digital Quill Publishing</title>
    <link rel="stylesheet" href="{{ url_for('static', filename='css/style.css') }}">
</head>
<body>
    <header>
        <h1>Digital Quill Publishing</h1>
        <nav>
            <a href="{{ url_for('home') }}">Home</a>
            {% if current_user.is_authenticated %}
                <a href="{{ url_for('dashboard') }}">Dashboard</a>
                <a href="{{ url_for('logout') }}">Logout</a>
            {% else %}
                <a href="{{ url_for('login') }}">Login</a>
            {% endif %}
        </nav>
    </header>
    
    <main>
        {% with messages = get_flashed_messages() %}
            {% if messages %}
                <div class="flashes">
                    {% for message in messages %}
                        <div class="flash">{{ message }}</div>
                    {% endfor %}
                </div>
            {% endif %}
        {% endwith %}
        
        {% block content %}{% endblock %}
    </main>
    
    <footer>
        <p>&copy; 2025 Digital Quill Publishing</p>
    </footer>
</body>
</html>
```

#### Exercise 7.1: Flask Setup
1. Create a basic Flask application with the structure above
2. Add a home.html template that extends base.html
3. Create a simple CSS file in the static folder
4. Run your application and verify it works in a browser

### 7.2 Creating User Authentication

#### User Model and Login:
```python
# models.py
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

class User(UserMixin):
    def __init__(self, id, username, email, password_hash):
        self.id = id
        self.username = username
        self.email = email
        self.password_hash = password_hash
        
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    @staticmethod
    def create_user(username, email, password):
        password_hash = generate_password_hash(password)
        # In a real application, save to database
        return User(1, username, email, password_hash)
```

#### Login Routes:
```python
# app.py (additional code)
from models import User

# Mock user database
users = {
    1: User(1, "author1", "author1@example.com", 
            generate_password_hash("password123"))
}

@login_manager.user_loader
def load_user(user_id):
    return users.get(int(user_id))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        # Find user by email (in real app, query database)
        user = next((u for u in users.values() if u.email == email), None)
        
        if user and user.check_password(password):
            login_user(user)
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid email or password')
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('login'))
```

#### Login Template:
```html
<!-- templates/login.html -->
{% extends "base.html" %}

{% block content %}
<div class="login-container">
    <h2>Login</h2>
    
    <form method="POST">
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" required>
        </div>
        
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>
        </div>
        
        <button type="submit">Login</button>
    </form>
</div>
{% endblock %}
```

#### Exercise 7.2: Authentication
1. Implement the User model and login routes
2. Create the login template
3. Add a simple dashboard route and template that requires login
4. Test the login functionality with the mock user

### 7.3 Building the Manuscript Submission Form

#### Submission Form:
```python
# forms.py
from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileRequired, FileAllowed
from wtforms import StringField, TextAreaField, SelectField
from wtforms.validators import DataRequired, Length

class SubmissionForm(FlaskForm):
    title = StringField('Title', validators=[DataRequired()])
    genre = SelectField('Genre', choices=[
        ('fantasy', 'Fantasy'),
        ('sci_fi', 'Science Fiction'),
        ('mystery', 'Mystery/Thriller'),
        ('romance', 'Romance'),
        ('literary', 'Literary Fiction'),
        ('non_fiction', 'Non-Fiction')
    ])
    synopsis = TextAreaField('Synopsis', validators=[
        DataRequired(), 
        Length(max=500)
    ])
    manuscript = FileField('Manuscript', validators=[
        FileRequired(),
        FileAllowed(['doc', 'docx', 'pdf'], 'DOC, DOCX, or PDF files only!')
    ])
    cover_letter = TextAreaField('Cover Letter')
```

#### Submission Route:
```python
# app.py (additional code)
from forms import SubmissionForm
import os
from werkzeug.utils import secure_filename

UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/submit', methods=['GET', 'POST'])
@login_required
def submit_manuscript():
    form = SubmissionForm()
    
    if form.validate_on_submit():
        # Save manuscript file
        manuscript_file = form.manuscript.data
        filename = secure_filename(manuscript_file.filename)
        filepath = os.path.join(UPLOAD_FOLDER, filename)
        manuscript_file.save(filepath)
        
        # In a real application, save submission to database
        # and trigger the manuscript pipeline
        
        flash('Manuscript submitted successfully!')
        return redirect(url_for('dashboard'))
    
    return render_template('submission.html', form=form)
```

#### Submission Template:
```html
<!-- templates/submission.html -->
{% extends "base.html" %}

{% block content %}
<div class="submission-container">
    <h2>Submit Your Manuscript</h2>
    
    <form method="POST" enctype="multipart/form-data">
        {{ form.hidden_tag() }}
        
        <div class="form-group">
            <label for="title">Manuscript Title</label>
            {{ form.title(class="form-control") }}
        </div>
        
        <div class="form-group">
            <label for="genre">Genre</label>
            {{ form.genre(class="form-control") }}
        </div>
        
        <div class="form-group">
            <label for="synopsis">Synopsis (max 500 words)</label>
            {{ form.synopsis(class="form-control") }}
        </div>
        
        <div class="form-group">
            <label for="manuscript">Upload Manuscript (DOC, DOCX, or PDF)</label>
            {{ form.manuscript(class="form-control-file") }}
        </div>
        
        <div class="form-group">
            <label for="cover_letter">Cover Letter (optional)</label>
            {{ form.cover_letter(class="form-control") }}
        </div>
        
        <button type="submit" class="btn btn-primary">Submit Manuscript</button>
    </form>
</div>
{% endblock %}
```

#### Exercise 7.3: Submission Form
1. Implement the submission form and route
2. Create the submission template
3. Add a link to the submission form from the dashboard
4. Test the form by submitting a sample manuscript

## 8. Testing and Quality Assurance

### 8.1 Testing AI Components

#### Unit Testing AI Functions:
```python
# test_ai_components.py
import unittest
from acquisition_evaluation import evaluate_manuscript_chunk
from evaluation_criteria import ACQUISITION_CRITERIA
from plot_analysis import analyze_plot_structure
from character_analysis import analyze_characters

class TestAIComponents(unittest.TestCase):
    
    def setUp(self):
        self.test_text = """
        The old house stood at the end of the lane, its windows dark and shutters hanging loose.
        Sarah approached cautiously, her heart pounding in her chest. The key felt cold in her hand.
        "It's just an old house," she whispered to herself, but the words provided little comfort.
        As she inserted the key into the lock, a strange sound came from inside.
        """
    
    def test_acquisition_evaluation(self):
        result = evaluate_manuscript_chunk(self.test_text, ACQUISITION_CRITERIA)
        self.assertIn("Writing Quality", result)
        self.assertIn("Plot and Structure", result)
        self.assertIn("Character Development", result)
        self.assertIn("Market Potential", result)
        self.assertIn("Recommendation", result)
    
    def test_plot_analysis(self):
        result = analyze_plot_structure(self.test_text)
        self.assertIsNotNone(result)
        self.assertTrue(len(result) > 100)  # Should provide substantial analysis
    
    def test_character_analysis(self):
        result = analyze_characters(self.test_text)
        self.assertIn("Sarah", result)  # Should identify the character

if __name__ == '__main__':
    unittest.main()
```

#### Testing with Different Genres:
```python
# test_genres.py
import unittest
from genre_classification import classify_genre

class TestGenreClassification(unittest.TestCase):
    
    def test_mystery_genre(self):
        mystery_text = """
        The detective examined the room carefully, noting the position of the overturned chair
        and the faint scuff marks on the hardwood floor. "The victim knew the killer," he said,
        pointing to the untouched glass of whiskey. "This wasn't a random break-in."
        """
        result = classify_genre(mystery_text)
        self.assertIn("Mystery", result)
    
    def test_fantasy_genre(self):
        fantasy_text = """
        The dragon circled overhead, its scales gleaming like rubies in the sunlight.
        Elara raised her enchanted bow, whispering the ancient words her grandmother had taught her.
        The arrow began to glow with a blue light as magic coursed through it.
        """
        result = classify_genre(fantasy_text)
        self.assertIn("Fantasy", result)
    
    def test_romance_genre(self):
        romance_text = """
        Their eyes met across the crowded room, and for a moment, everything else faded away.
        She felt her heart skip a beat as he smiled and made his way toward her.
        After all these years, he still had that effect on her.
        """
        result = classify_genre(romance_text)
        self.assertIn("Romance", result)

if __name__ == '__main__':
    unittest.main()
```

#### Exercise 8.1: AI Testing
1. Create unit tests for your AI components
2. Write test cases with different types of content
3. Implement at least one edge case test (very short text, unusual content, etc.)
4. Run your tests and fix any issues found

### 8.2 Testing Web Components

#### Flask Testing:
```python
# test_web_app.py
import unittest
from app import app
import os

class FlaskAppTests(unittest.TestCase):
    
    def setUp(self):
        app.config['TESTING'] = True
        app.config['WTF_CSRF_ENABLED'] = False
        self.client = app.test_client()
        
        # Create test upload directory
        os.makedirs('uploads', exist_ok=True)
    
    def test_home_page(self):
        response = self.client.get('/')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Digital Quill Publishing', response.data)
    
    def test_login_page(self):
        response = self.client.get('/login')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Login', response.data)
    
    def test_login_functionality(self):
        response = self.client.post('/login', data={
            'email': 'author1@example.com',
            'password': 'password123'
        }, follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Dashboard', response.data)
    
    def test_protected_routes(self):
        # Should redirect to login when not authenticated
        response = self.client.get('/dashboard', follow_redirects=True)
        self.assertIn(b'Login', response.data)

if __name__ == '__main__':
    unittest.main()
```

#### Form Validation Testing:
```python
# test_forms.py
import unittest
from app import app
import io

class FormTests(unittest.TestCase):
    
    def setUp(self):
        app.config['TESTING'] = True
        app.config['WTF_CSRF_ENABLED'] = False
        self.client = app.test_client()
        
        # Login first
        self.client.post('/login', data={
            'email': 'author1@example.com',
            'password': 'password123'
        })
    
    def test_submission_form_validation(self):
        # Test missing required fields
        response = self.client.post('/submit', data={
            'title': '',  # Missing title
            'genre': 'fantasy',
            'synopsis': 'A test synopsis'
        }, follow_redirects=True)
        self.assertIn(b'This field is required', response.data)
        
        # Test file type validation
        response = self.client.post('/submit', data={
            'title': 'Test Manuscript',
            'genre': 'fantasy',
            'synopsis': 'A test synopsis',
            'manuscript': (io.BytesIO(b'test content'), 'test.txt')  # Wrong file type
        }, follow_redirects=True)
        self.assertIn(b'DOC, DOCX, or PDF files only', response.data)
        
        # Test successful submission
        response = self.client.post('/submit', data={
            'title': 'Test Manuscript',
            'genre': 'fantasy',
            'synopsis': 'A test synopsis',
            'manuscript': (io.BytesIO(b'test content'), 'test.docx'),
            'cover_letter': 'A test cover letter'
        }, follow_redirects=True)
        self.assertIn(b'Manuscript submitted successfully', response.data)

if __name__ == '__main__':
    unittest.main()
```

#### Exercise 8.2: Web Testing
1. Implement the Flask testing examples
2. Add tests for any additional routes in your application
3. Create tests for form validation
4. Run your tests and fix any issues found

### 8.3 Integration Testing

#### Testing the Complete Pipeline:
```python
# test_integration.py
import unittest
import os
from manuscript_pipeline import process_manuscript

class IntegrationTests(unittest.TestCase):
    
    def setUp(self):
        # Create test directories
        os.makedirs('test_manuscripts', exist_ok=True)
        os.makedirs('test_results', exist_ok=True)
        
        # Create a simple test manuscript
        with open('test_manuscripts/test_manuscript.txt', 'w') as f:
            f.write("""
            The Mystery of Willow Creek
            
            Chapter 1
            
            The small town of Willow Creek had always been quiet, almost eerily so.
            But when the mayor's daughter disappeared on a foggy Tuesday night,
            the silence was shattered by whispers and accusations.
            
            Detective James Morgan rubbed his tired eyes as he reviewed the case notes.
            This was the third disappearance in as many months, and he was no closer to finding answers.
            The coffee on his desk had gone cold hours ago, much like the trail of evidence.
            
            "Detective?" Officer Chen appeared in the doorway. "We found something by the creek."
            """)
        
        # Test metadata
        self.test_metadata = {
            "id": 1,
            "title": "The Mystery of Willow Creek",
            "author": "Test Author",
            "genre": "Mystery",
            "submission_date": "2025-04-01"
        }
    
    def test_complete_pipeline(self):
        results = process_manuscript(
            'test_manuscripts/test_manuscript.txt',
            self.test_metadata
        )
        
        # Check that all expected components are present
        self.assertIn("key_elements", results)
        self.assertIn("genre_analysis", results)
        self.assertIn("evaluations", results)
        
        # Save results for manual review
        with open('test_results/pipeline_results.txt', 'w') as f:
            for key, value in results.items():
                f.write(f"=== {key} ===\n")
                f.write(str(value))
                f.write("\n\n")
        
        # Basic validation of results
        self.assertIn("Detective James Morgan", results["key_elements"])
        self.assertIn("Mystery", results["genre_analysis"])

if __name__ == '__main__':
    unittest.main()
```

#### Exercise 8.3: Integration Testing
1. Create a test manuscript file
2. Implement the integration test for your pipeline
3. Add assertions to verify the results
4. Run the test and analyze the output
5. Identify any integration issues and fix them

## 9. Deployment Basics

### 9.1 Preparing for Deployment

#### Creating a Requirements File:
```bash
# In your virtual environment
pip freeze > requirements.txt
```

#### Setting Up Environment Variables:
```bash
# Create a .env.production file
echo "FLASK_ENV=production" > .env.production
echo "FLASK_APP=app.py" >> .env.production
echo "SECRET_KEY=your_production_secret_key" >> .env.production
echo "OPENAI_API_KEY=your_production_api_key" >> .env.production
```

#### Creating a Production Config:
```python
# config.py
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY', 'dev-key')
    UPLOAD_FOLDER = 'uploads'
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB max upload

class ProductionConfig(Config):
    DEBUG = False
    TESTING = False
    # Add production database URI

class DevelopmentConfig(Config):
    DEBUG = True

class TestingConfig(Config):
    TESTING = True
```

#### Exercise 9.1: Deployment Preparation
1. Create a requirements.txt file for your project
2. Set up a .env.production file with appropriate variables
3. Implement the configuration classes
4. Update your app to use the configuration based on environment

### 9.2 Basic Deployment Options

#### Local Deployment with Gunicorn:
```bash
# Install Gunicorn
pip install gunicorn

# Run with Gunicorn
gunicorn -w 4 -b 0.0.0.0:8000 app:app
```

#### Docker Deployment:
```dockerfile
# Dockerfile
FROM python:3.9-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

ENV FLASK_APP=app.py
ENV FLASK_ENV=production

EXPOSE 8000

CMD ["gunicorn", "-w", "4", "-b", "0.0.0.0:8000", "app:app"]
```

```bash
# Build and run Docker container
docker build -t digital-quill .
docker run -p 8000:8000 digital-quill
```

#### Exercise 9.2: Local Deployment
1. Install Gunicorn in your virtual environment
2. Run your application with Gunicorn
3. Access your application at http://localhost:8000
4. If you have Docker installed, create a Dockerfile and test deployment

### 9.3 Cloud Deployment Options

#### Heroku Deployment:
```
# Procfile
web: gunicorn app:app
```

```bash
# Heroku deployment commands
heroku create digital-quill
git push heroku main
heroku config:set OPENAI_API_KEY=your_api_key
heroku open
```

#### AWS Elastic Beanstalk:
```
# .ebextensions/01_flask.config
option_settings:
  aws:elasticbeanstalk:application:environment:
    FLASK_APP: app.py
    FLASK_ENV: production
  aws:elasticbeanstalk:container:python:
    WSGIPath: app:app
```

```bash
# AWS EB deployment commands
pip install awsebcli
eb init -p python-3.9 digital-quill
eb create digital-quill-env
eb open
```

#### Exercise 9.3: Cloud Deployment Research
1. Research the cloud deployment options available to you
2. Create a comparison table of pros and cons for each option
3. Determine which option would be best for your Digital Quill implementation
4. Document the steps you would take to deploy to your chosen platform

## 10. Exercises and Practice Projects

### 10.1 Mini-Project: Genre Classifier

#### Project Description:
Build a specialized genre classifier that can:
1. Identify the genre and subgenre of a manuscript
2. Provide confidence scores for each classification
3. Suggest comparable titles in the same genre
4. Explain the key elements that indicate the genre

#### Implementation Steps:
1. Create a genre classification prompt template
2. Build a chain that processes text and identifies genre
3. Test with samples from different genres
4. Create a simple web interface for uploading samples
5. Display classification results with explanations

#### Expected Output:
```
Genre Classification Results:

Primary Genre: Mystery/Thriller
Subgenre: Police Procedural
Confidence: High (85%)

Key Indicators:
- Detective protagonist investigating a crime
- Emphasis on investigation process and evidence
- Small town setting with secrets
- Multiple suspects and red herrings

Comparable Titles:
1. "In the Woods" by Tana French
2. "The Cuckoo's Calling" by Robert Galbraith
3. "Still Life" by Louise Penny
```

### 10.2 Mini-Project: Character Development Analyzer

#### Project Description:
Create a specialized tool that analyzes character development in a manuscript:
1. Identifies all characters and their relationships
2. Tracks character arcs and development
3. Provides suggestions for improving character depth
4. Identifies stereotypes or clichés in characterization

#### Implementation Steps:
1. Create a character extraction function
2. Build a character analysis chain
3. Implement relationship mapping between characters
4. Generate specific improvement suggestions
5. Create a visualization of character relationships

#### Expected Output:
```
Character Analysis:

Main Characters:
1. James Morgan (Detective)
   - Arc: Struggling with past failure → Finding redemption
   - Depth: Moderate (7/10)
   - Suggestions: Develop backstory regarding previous case

2. Sarah Chen (Officer)
   - Arc: Rookie officer → Gaining confidence
   - Depth: Low (4/10)
   - Suggestions: Add personal stakes in the investigation

Relationships:
- Morgan and Chen: Professional, mentor/mentee dynamic
- Morgan and Mayor: Tense, adversarial

Character Development Opportunities:
1. Add more internal conflict for Morgan
2. Develop Chen's personal life and motivations
3. Create more complex relationship dynamics
```

### 10.3 Mini-Project: Editorial Letter Generator

#### Project Description:
Build a comprehensive editorial letter generator that:
1. Analyzes multiple aspects of a manuscript
2. Provides balanced feedback (strengths and weaknesses)
3. Generates specific, actionable revision suggestions
4. Maintains an encouraging, constructive tone

#### Implementation Steps:
1. Create analysis functions for different aspects (plot, characters, pacing, etc.)
2. Build a template for the editorial letter
3. Implement a balancing mechanism for positive and constructive feedback
4. Generate specific examples from the text to support feedback
5. Create a professional formatting system for the letter

#### Expected Output:
A professionally formatted editorial letter with:
- Personalized greeting
- Overview of manuscript strengths
- Detailed analysis of different elements
- Specific examples from the text
- Actionable revision suggestions
- Encouraging conclusion and next steps

### 10.4 Capstone Project: Mini Author Portal

#### Project Description:
Create a simplified version of the Author Portal that:
1. Allows manuscript uploads
2. Processes manuscripts through AI evaluation
3. Generates and displays feedback
4. Tracks manuscript status
5. Provides a dashboard for authors

#### Implementation Steps:
1. Create a Flask web application with user authentication
2. Implement manuscript upload functionality
3. Build a processing pipeline for manuscripts
4. Create a dashboard to display results
5. Implement status tracking for manuscripts
6. Add feedback display functionality

#### Expected Deliverable:
A working web application that demonstrates the core functionality of Digital Quill Publishing, including:
- User login and registration
- Manuscript submission form
- AI processing of manuscripts
- Dashboard showing manuscript status
- Detailed feedback display
- Simple admin interface
