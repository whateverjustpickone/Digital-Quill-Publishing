// Organizational Chart Implementation using D3.js
document.addEventListener('DOMContentLoaded', function() {
    // Publishing house organizational data
    const orgData = {
        name: "Digital Quill Publishing",
        title: "Virtual Publishing House",
        children: [
            {
                name: "Executive Leadership",
                title: "Department",
                children: [
                    { name: "Publisher AI", title: "AI Agent", description: "Sets strategic vision and makes final acquisition decisions" }
                ]
            },
            {
                name: "Editorial Department",
                title: "Department",
                children: [
                    { name: "Acquisition Editor AI", title: "AI Agent", description: "Evaluates and acquires new manuscripts", status: "active" },
                    { name: "Developmental Editor AI", title: "AI Agent", description: "Works with authors on content development" },
                    { name: "Copy Editor AI", title: "AI Agent", description: "Reviews manuscripts for grammar and style" },
                    { name: "Managing Editor AI", title: "AI Agent", description: "Oversees workflow from editorial through production" },
                    { name: "Editorial Assistant AI", title: "AI Agent", description: "Provides administrative support" }
                ]
            },
            {
                name: "Production Department",
                title: "Department",
                children: [
                    { name: "Production Manager AI", title: "AI Agent", description: "Oversees pre-press and manufacturing" },
                    { name: "Typesetter/Formatter AI", title: "AI Agent", description: "Formats manuscripts according to specifications" },
                    { name: "Digital Production Specialist AI", title: "AI Agent", description: "Develops ebook formats" }
                ]
            },
            {
                name: "Creative Department",
                title: "Department",
                children: [
                    { name: "Art Director AI", title: "AI Agent", description: "Leads jacket design" },
                    { name: "Book Designer AI", title: "AI Agent", description: "Designs book interiors" },
                    { name: "Promotion Designer AI", title: "AI Agent", description: "Creates catalogs and marketing materials" }
                ]
            },
            {
                name: "Marketing and Publicity",
                title: "Department",
                children: [
                    { name: "Marketing Director AI", title: "AI Agent", description: "Develops marketing strategies" },
                    { name: "Publicist AI", title: "AI Agent", description: "Generates media exposure" },
                    { name: "Social Media Manager AI", title: "AI Agent", description: "Manages online presence" },
                    { name: "Digital Marketing Specialist AI", title: "AI Agent", description: "Implements online campaigns" }
                ]
            },
            {
                name: "Sales Department",
                title: "Department",
                children: [
                    { name: "Sales Director AI", title: "AI Agent", description: "Develops sales strategies" },
                    { name: "Sales Representative AI", title: "AI Agent", description: "Sells to retailers and distributors" },
                    { name: "Educational Sales Specialist AI", title: "AI Agent", description: "Focuses on schools and libraries" }
                ]
            },
            {
                name: "Legal and Contracts",
                title: "Department",
                children: [
                    { name: "Contracts Manager AI", title: "AI Agent", description: "Drafts and manages author contracts" },
                    { name: "Legal Counsel AI", title: "AI Agent", description: "Handles intellectual property matters" }
                ]
            },
            {
                name: "Subsidiary Rights",
                title: "Department",
                children: [
                    { name: "Subsidiary Rights Manager AI", title: "AI Agent", description: "Sells content rights for various formats" },
                    { name: "Foreign Rights Specialist AI", title: "AI Agent", description: "Focuses on international sales" }
                ]
            },
            {
                name: "Support Departments",
                title: "Department",
                children: [
                    { name: "Finance Manager AI", title: "AI Agent", description: "Monitors profit and loss" },
                    { name: "IT Specialist AI", title: "AI Agent", description: "Maintains infrastructure" },
                    { name: "Human Resources Manager AI", title: "AI Agent", description: "Manages AI agent performance" },
                    { name: "Warehouse Manager AI", title: "AI Agent", description: "Oversees inventory and distribution" }
                ]
            }
        ]
    };

    // Initialize the organizational chart
    window.orgChart = createOrgChart('#org-chart', orgData);

    // Create and return the organizational chart object
    function createOrgChart(selector, data) {
        const container = d3.select(selector);
        const width = container.node().getBoundingClientRect().width;
        const height = container.node().getBoundingClientRect().height;
        
        // Create SVG element
        const svg = container.append('svg')
            .attr('width', width)
            .attr('height', height)
            .attr('viewBox', [0, 0, width, height])
            .call(d3.zoom().on('zoom', function(event) {
                g.attr('transform', event.transform);
            }));
        
        // Create a group for the chart content
        const g = svg.append('g');
        
        // Create hierarchical layout
        const root = d3.hierarchy(data);
        
        // Set fixed dimensions for nodes
        const nodeWidth = 180;
        const nodeHeight = 80;
        const nodeSpacing = 20;
        
        // Calculate tree layout
        const treeLayout = d3.tree()
            .nodeSize([nodeHeight + nodeSpacing, nodeWidth + nodeSpacing])
            .separation((a, b) => a.parent === b.parent ? 1.2 : 1.5);
        
        // Apply layout to data
        treeLayout(root);
        
        // Calculate the bounds of the tree
        let minX = Infinity;
        let maxX = -Infinity;
        let minY = Infinity;
        let maxY = -Infinity;
        
        root.each(d => {
            minX = Math.min(minX, d.x - nodeHeight / 2);
            maxX = Math.max(maxX, d.x + nodeHeight / 2);
            minY = Math.min(minY, d.y - nodeWidth / 2);
            maxY = Math.max(maxY, d.y + nodeWidth / 2);
        });
        
        // Center the tree in the viewport
        const centerX = (minX + maxX) / 2;
        const centerY = (minY + maxY) / 2;
        
        // Create links between nodes
        const links = g.append('g')
            .attr('class', 'links')
            .selectAll('path')
            .data(root.links())
            .enter()
            .append('path')
            .attr('d', d => {
                return `M${d.source.y},${d.source.x}
                        C${(d.source.y + d.target.y) / 2},${d.source.x}
                         ${(d.source.y + d.target.y) / 2},${d.target.x}
                         ${d.target.y},${d.target.x}`;
            })
            .attr('fill', 'none')
            .attr('stroke', '#ccc')
            .attr('stroke-width', 1.5);
        
        // Create nodes
        const nodes = g.append('g')
            .attr('class', 'nodes')
            .selectAll('g')
            .data(root.descendants())
            .enter()
            .append('g')
            .attr('class', d => `node ${d.data.title.toLowerCase().replace(/\s+/g, '-')}`)
            .attr('transform', d => `translate(${d.y},${d.x})`)
            .on('click', function(event, d) {
                // Handle node click - show agent details in workspace
                if (d.data.title === "AI Agent") {
                    showAgentWorkspace(d.data);
                } else if (d.data.title === "Department") {
                    // Toggle expand/collapse for departments
                    toggleDepartment(d);
                }
            });
        
        // Add rectangles for nodes
        nodes.append('rect')
            .attr('width', nodeWidth)
            .attr('height', nodeHeight)
            .attr('x', -nodeWidth / 2)
            .attr('y', -nodeHeight / 2)
            .attr('rx', 5)
            .attr('ry', 5)
            .attr('fill', d => {
                if (d.data.title === "Department") return "#3498db";
                if (d.data.status === "active") return "#2ecc71";
                return "#f39c12";
            })
            .attr('stroke', '#2c3e50')
            .attr('stroke-width', 1);
        
        // Add node titles
        nodes.append('text')
            .attr('dy', '-1em')
            .attr('text-anchor', 'middle')
            .attr('fill', 'white')
            .style('font-weight', 'bold')
            .style('font-size', '12px')
            .text(d => d.data.name);
        
        // Add node subtitles
        nodes.append('text')
            .attr('dy', '1em')
            .attr('text-anchor', 'middle')
            .attr('fill', 'white')
            .style('font-size', '10px')
            .text(d => d.data.title);
        
        // Initial center and scale
        const initialTransform = d3.zoomIdentity
            .translate(width / 2, height / 2)
            .scale(0.8)
            .translate(-centerY, -centerX);
        
        svg.call(d3.zoom().transform, initialTransform);
        
        // Function to show agent details in workspace
        function showAgentWorkspace(agentData) {
            const agentInfo = document.querySelector('.agent-info');
            const agentWorkspace = document.querySelector('.agent-workspace');
            const workspacePanel = document.querySelector('.workspace-panel');
            
            // Update agent info
            agentInfo.innerHTML = `
                <div class="agent-avatar">
                    <i class="fas fa-user-tie"></i>
                </div>
                <div class="agent-details">
                    <h3>${agentData.name}</h3>
                    <p>${agentData.description}</p>
                </div>
            `;
            
            // Update agent workspace
            agentWorkspace.innerHTML = `
                <div class="agent-status">
                    <span class="status-indicator ${agentData.status === 'active' ? 'active' : 'inactive'}">
                        ${agentData.status === 'active' ? 'Active' : 'Inactive'}
                    </span>
                </div>
                <div class="agent-tasks">
                    <h4>Current Tasks</h4>
                    ${agentData.status === 'active' ? 
                        `<div class="task">
                            <div class="task-header">
                                <span class="task-title">Manuscript Evaluation</span>
                                <span class="task-status">In Progress</span>
                            </div>
                            <div class="task-progress">
                                <div class="progress-bar" style="width: 65%"></div>
                            </div>
                        </div>` : 
                        `<p>No active tasks</p>`
                    }
                </div>
                <div class="agent-actions">
                    <h4>Actions</h4>
                    <button class="action-button">
                        <i class="fas fa-play"></i> Activate Agent
                    </button>
                    <button class="action-button">
                        <i class="fas fa-comment"></i> Chat with Agent
                    </button>
                    <button class="action-button">
                        <i class="fas fa-cog"></i> Configure
                    </button>
                </div>
            `;
            
            // Show workspace panel
            workspacePanel.classList.add('active');
            
            // Add event listeners to workspace buttons
            document.querySelectorAll('.action-button').forEach(button => {
                button.addEventListener('click', function(e) {
                    e.preventDefault();
                    // For demo purposes, just show a message in chat
                    const chatMessages = document.querySelector('.chat-messages');
                    const actionText = this.textContent.trim();
                    const messageDiv = document.createElement('div');
                    messageDiv.className = 'system-message';
                    messageDiv.innerHTML = `<p>Action requested: ${actionText} for ${agentData.name}</p>`;
                    chatMessages.appendChild(messageDiv);
                });
            });
        }
        
        // Function to toggle department expansion/collapse
        function toggleDepartment(d) {
            // This would be implemented for a more interactive version
            console.log(`Toggle department: ${d.data.name}`);
        }
        
        // Return public methods for the chart
        return {
            zoomIn: function() {
                const currentTransform = d3.zoomTransform(svg.node());
                svg.transition().duration(300).call(
                    d3.zoom().transform,
                    d3.zoomIdentity
                        .translate(currentTransform.x, currentTransform.y)
                        .scale(currentTransform.k * 1.2)
                );
            },
            zoomOut: function() {
                const currentTransform = d3.zoomTransform(svg.node());
                svg.transition().duration(300).call(
                    d3.zoom().transform,
                    d3.zoomIdentity
                        .translate(currentTransform.x, currentTransform.y)
                        .scale(currentTransform.k / 1.2)
                );
            },
            resetView: function() {
                svg.transition().duration(500).call(
                    d3.zoom().transform,
                    initialTransform
                );
            }
        };
    }
});
