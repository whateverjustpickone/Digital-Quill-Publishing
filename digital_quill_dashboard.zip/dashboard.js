// Dashboard main functionality
document.addEventListener('DOMContentLoaded', function() {
    // Theme toggling
    const toggleThemeButton = document.getElementById('toggle-theme');
    toggleThemeButton.addEventListener('click', function() {
        document.body.classList.toggle('dark-theme');
        const icon = this.querySelector('i');
        if (icon.classList.contains('fa-moon')) {
            icon.classList.replace('fa-moon', 'fa-sun');
        } else {
            icon.classList.replace('fa-sun', 'fa-moon');
        }
    });

    // Zoom controls for org chart
    const zoomInButton = document.getElementById('zoom-in');
    const zoomOutButton = document.getElementById('zoom-out');
    const resetViewButton = document.getElementById('reset-view');

    zoomInButton.addEventListener('click', function() {
        // This will be connected to the org chart zoom functionality
        if (window.orgChart && window.orgChart.zoomIn) {
            window.orgChart.zoomIn();
        }
    });

    zoomOutButton.addEventListener('click', function() {
        // This will be connected to the org chart zoom functionality
        if (window.orgChart && window.orgChart.zoomOut) {
            window.orgChart.zoomOut();
        }
    });

    resetViewButton.addEventListener('click', function() {
        // This will be connected to the org chart reset functionality
        if (window.orgChart && window.orgChart.resetView) {
            window.orgChart.resetView();
        }
    });

    // Chat panel controls
    const minimizeChatButton = document.getElementById('minimize-chat');
    const expandChatButton = document.getElementById('expand-chat');
    const chatPanel = document.querySelector('.chat-panel');
    const chatMessages = document.querySelector('.chat-messages');

    minimizeChatButton.addEventListener('click', function() {
        chatPanel.style.height = '40px';
        chatMessages.style.display = 'none';
        document.querySelector('.chat-input').style.display = 'none';
    });

    expandChatButton.addEventListener('click', function() {
        chatPanel.style.height = '400px';
        chatMessages.style.display = 'flex';
        document.querySelector('.chat-input').style.display = 'flex';
    });

    // Workspace panel controls
    const closeWorkspaceButton = document.getElementById('close-workspace');
    const workspacePanel = document.querySelector('.workspace-panel');

    closeWorkspaceButton.addEventListener('click', function() {
        workspacePanel.classList.remove('active');
    });

    // Responsive controls for mobile
    function setupResponsiveControls() {
        const sidebar = document.querySelector('.sidebar');
        
        // Create menu toggle button for mobile
        const menuToggle = document.createElement('button');
        menuToggle.id = 'menu-toggle';
        menuToggle.innerHTML = '<i class="fas fa-bars"></i>';
        menuToggle.classList.add('mobile-menu-toggle');
        document.querySelector('.logo').appendChild(menuToggle);
        
        menuToggle.addEventListener('click', function() {
            sidebar.classList.toggle('active');
        });
        
        // Close sidebar when clicking outside
        document.addEventListener('click', function(event) {
            if (!sidebar.contains(event.target) && event.target !== menuToggle) {
                sidebar.classList.remove('active');
            }
        });
    }

    // Only setup mobile controls if screen width is below threshold
    if (window.innerWidth <= 768) {
        setupResponsiveControls();
    }

    // Handle window resize
    window.addEventListener('resize', function() {
        if (window.innerWidth <= 768 && !document.getElementById('menu-toggle')) {
            setupResponsiveControls();
        }
    });
});
