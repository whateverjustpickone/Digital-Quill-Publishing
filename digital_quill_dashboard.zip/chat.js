// Chat functionality for Digital Quill Publishing Dashboard
document.addEventListener('DOMContentLoaded', function() {
    // Chat elements
    const chatMessages = document.querySelector('.chat-messages');
    const messageInput = document.getElementById('message-input');
    const sendMessageButton = document.getElementById('send-message');
    const attachFileButton = document.getElementById('attach-file');
    
    // AI agent data for chat responses
    const aiAgents = {
        "system": {
            name: "Digital Quill System",
            role: "System Assistant"
        },
        "acquisition_editor": {
            name: "Acquisition Editor AI",
            role: "Evaluates manuscript submissions"
        },
        "developmental_editor": {
            name: "Developmental Editor AI",
            role: "Provides substantive feedback"
        },
        "publisher": {
            name: "Publisher AI",
            role: "Makes final acquisition decisions"
        }
    };
    
    // Currently active agent in chat
    let activeAgent = "system";
    
    // Add event listener for send button
    sendMessageButton.addEventListener('click', sendMessage);
    
    // Add event listener for Enter key in input field
    messageInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });
    
    // Add event listener for file attachment
    attachFileButton.addEventListener('click', function() {
        // In a real implementation, this would open a file picker
        addSystemMessage("File attachment functionality would be implemented here.");
    });
    
    // Function to send a message
    function sendMessage() {
        const message = messageInput.value.trim();
        if (message === '') return;
        
        // Add user message to chat
        addUserMessage(message);
        
        // Clear input field
        messageInput.value = '';
        
        // Process message and generate response
        processMessage(message);
    }
    
    // Function to add a user message to the chat
    function addUserMessage(message) {
        const messageElement = document.createElement('div');
        messageElement.className = 'user-message';
        messageElement.innerHTML = `
            <div class="message-content">
                <p>${message}</p>
                <span class="message-time">${getCurrentTime()}</span>
            </div>
        `;
        chatMessages.appendChild(messageElement);
        scrollToBottom();
    }
    
    // Function to add an AI agent message to the chat
    function addAgentMessage(message, agent = activeAgent) {
        const agentInfo = aiAgents[agent];
        const messageElement = document.createElement('div');
        messageElement.className = 'agent-message';
        messageElement.innerHTML = `
            <div class="agent-icon">
                <i class="fas fa-robot"></i>
            </div>
            <div class="message-content">
                <div class="agent-name">${agentInfo.name}</div>
                <p>${message}</p>
                <span class="message-time">${getCurrentTime()}</span>
            </div>
        `;
        chatMessages.appendChild(messageElement);
        scrollToBottom();
    }
    
    // Function to add a system message to the chat
    function addSystemMessage(message) {
        const messageElement = document.createElement('div');
        messageElement.className = 'system-message';
        messageElement.innerHTML = `<p>${message}</p>`;
        chatMessages.appendChild(messageElement);
        scrollToBottom();
    }
    
    // Function to process user message and generate response
    function processMessage(message) {
        // Simulate typing indicator
        const typingIndicator = document.createElement('div');
        typingIndicator.className = 'typing-indicator';
        typingIndicator.innerHTML = `
            <div class="agent-icon">
                <i class="fas fa-robot"></i>
            </div>
            <div class="typing-dots">
                <span></span>
                <span></span>
                <span></span>
            </div>
        `;
        chatMessages.appendChild(typingIndicator);
        scrollToBottom();
        
        // Simulate AI response delay
        setTimeout(() => {
            // Remove typing indicator
            chatMessages.removeChild(typingIndicator);
            
            // Generate response based on message content
            let response;
            let respondingAgent = activeAgent;
            
            // Check for agent switching commands
            if (message.toLowerCase().includes("talk to acquisition editor")) {
                activeAgent = "acquisition_editor";
                addSystemMessage(`Switching to ${aiAgents[activeAgent].name}`);
                response = "Hello, I'm the Acquisition Editor AI. I can help evaluate your manuscript and provide initial feedback. How can I assist you today?";
            } 
            else if (message.toLowerCase().includes("talk to developmental editor")) {
                activeAgent = "developmental_editor";
                addSystemMessage(`Switching to ${aiAgents[activeAgent].name}`);
                response = "Hello, I'm the Developmental Editor AI. I specialize in providing substantive feedback on manuscript structure and content. How can I help improve your work?";
            }
            else if (message.toLowerCase().includes("talk to publisher")) {
                activeAgent = "publisher";
                addSystemMessage(`Switching to ${aiAgents[activeAgent].name}`);
                response = "Hello, I'm the Publisher AI. I oversee the strategic direction of Digital Quill Publishing and make final acquisition decisions. What would you like to discuss?";
            }
            // Check for specific queries
            else if (message.toLowerCase().includes("manuscript") || message.toLowerCase().includes("submission")) {
                if (activeAgent === "acquisition_editor") {
                    response = "I'd be happy to review your manuscript. You can upload it through the submissions portal, and I'll provide a comprehensive evaluation including plot, character development, pacing, prose style, and market potential.";
                } else if (activeAgent === "developmental_editor") {
                    response = "As a Developmental Editor, I can provide in-depth feedback on your manuscript's structure, character arcs, pacing, and thematic elements. Would you like me to focus on any specific aspect of your work?";
                } else {
                    response = "Our editorial team would be happy to review your manuscript. Would you like me to connect you with our Acquisition Editor AI for an initial evaluation?";
                }
            }
            else if (message.toLowerCase().includes("feedback") || message.toLowerCase().includes("review")) {
                if (activeAgent === "acquisition_editor") {
                    response = "I provide comprehensive manuscript evaluations with specific scores and actionable suggestions in areas like plot & structure, character development, pacing & flow, prose & style, and market potential.";
                } else if (activeAgent === "developmental_editor") {
                    response = "My feedback focuses on deeper structural and content issues. I can help with character development, plot holes, pacing problems, and thematic consistency. I also provide specific revision suggestions tailored to your manuscript's needs.";
                } else {
                    response = "Our AI editors provide different types of feedback depending on your needs. The Acquisition Editor offers initial manuscript evaluations, while the Developmental Editor provides more in-depth revision guidance.";
                }
            }
            else if (message.toLowerCase().includes("process") || message.toLowerCase().includes("workflow")) {
                response = "The Digital Quill Publishing workflow begins with manuscript submission to the Acquisition Editor AI for initial evaluation. If accepted, the Developmental Editor AI works with you on revisions. Then it moves to Copy Editor AI for language refinement, followed by production, design, and marketing phases.";
            }
            else if (message.toLowerCase().includes("help") || message.toLowerCase().includes("commands")) {
                response = "You can use the following commands:<br>- 'Talk to Acquisition Editor'<br>- 'Talk to Developmental Editor'<br>- 'Talk to Publisher'<br><br>You can also ask about manuscript submissions, feedback, the publishing process, or specific AI agent roles.";
            }
            // Default responses
            else {
                const defaultResponses = {
                    "system": "I'm the Digital Quill System assistant. I can help you navigate our virtual publishing house and connect you with the appropriate AI agents. What would you like to know about?",
                    "acquisition_editor": "As the Acquisition Editor AI, I'm here to evaluate your manuscript and determine if it's a good fit for Digital Quill Publishing. Would you like to discuss your submission or get information about our evaluation process?",
                    "developmental_editor": "As the Developmental Editor AI, I focus on helping you improve your manuscript's structure, characters, and overall narrative. Is there a specific aspect of your writing you'd like to enhance?",
                    "publisher": "As the Publisher AI, I oversee the strategic direction of Digital Quill Publishing. I'd be happy to discuss our publishing philosophy, acquisition criteria, or market trends."
                };
                response = defaultResponses[activeAgent];
            }
            
            // Add AI response to chat
            addAgentMessage(response, respondingAgent);
        }, 1500); // 1.5 second delay for realistic typing simulation
    }
    
    // Function to scroll chat to bottom
    function scrollToBottom() {
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    
    // Function to get current time in HH:MM format
    function getCurrentTime() {
        const now = new Date();
        let hours = now.getHours();
        let minutes = now.getMinutes();
        const ampm = hours >= 12 ? 'PM' : 'AM';
        
        hours = hours % 12;
        hours = hours ? hours : 12; // Convert 0 to 12
        minutes = minutes < 10 ? '0' + minutes : minutes;
        
        return `${hours}:${minutes} ${ampm}`;
    }
    
    // Add initial welcome message
    setTimeout(() => {
        addAgentMessage("Welcome to Digital Quill Publishing! I'm the system assistant and can help you navigate our virtual publishing house. You can ask about our publishing process, submit manuscripts for evaluation, or chat with specific AI agents like our Acquisition Editor or Developmental Editor. How can I assist you today?");
    }, 500);
});
