// Agent Workspace Functionality
document.addEventListener('DOMContentLoaded', function() {
    // Create workspace HTML structure for each agent
    function createAgentWorkspace(agentData) {
        // Update the workspace panel with agent-specific content
        const workspaceContent = document.querySelector('.agent-workspace');
        
        // Create the workspace HTML
        workspaceContent.innerHTML = `
            <div class="agent-workspace-container">
                <div class="agent-workspace-header">
                    <h3>${agentData.name}</h3>
                    <div class="agent-status">
                        <span class="status-indicator ${agentData.status || 'inactive'}">
                            ${agentData.status === 'active' ? 'Active' : 'Inactive'}
                        </span>
                    </div>
                </div>
                
                <div class="agent-workspace-tabs">
                    <button class="workspace-tab active" data-tab="current-work">Current Work</button>
                    <button class="workspace-tab" data-tab="history">History</button>
                    <button class="workspace-tab" data-tab="stats">Stats</button>
                    <button class="workspace-tab" data-tab="settings">Settings</button>
                </div>
                
                <div class="workspace-content">
                    <!-- Current Work Panel -->
                    <div class="workspace-panel active" id="current-work-panel">
                        <div class="current-work">
                            ${generateCurrentWorkItems(agentData)}
                        </div>
                    </div>
                    
                    <!-- History Panel -->
                    <div class="workspace-panel" id="history-panel">
                        <div class="history-list">
                            ${generateHistoryItems(agentData)}
                        </div>
                    </div>
                    
                    <!-- Stats Panel -->
                    <div class="workspace-panel" id="stats-panel">
                        <div class="stats-grid">
                            <div class="stat-card">
                                <div class="stat-value">${Math.floor(Math.random() * 50) + 10}</div>
                                <div class="stat-label">Tasks Completed</div>
                            </div>
                            <div class="stat-card">
                                <div class="stat-value">${Math.floor(Math.random() * 20) + 1}</div>
                                <div class="stat-label">In Progress</div>
                            </div>
                            <div class="stat-card">
                                <div class="stat-value">${Math.floor(Math.random() * 100) + 80}%</div>
                                <div class="stat-label">Accuracy Rate</div>
                            </div>
                            <div class="stat-card">
                                <div class="stat-value">${Math.floor(Math.random() * 10) + 1}h</div>
                                <div class="stat-label">Avg. Response Time</div>
                            </div>
                        </div>
                        
                        <div class="chart-container">
                            <div class="chart-header">
                                <div class="chart-title">Performance Trend</div>
                                <div class="chart-period">Last 30 Days</div>
                            </div>
                            <div class="chart-placeholder">
                                Performance chart would be displayed here
                            </div>
                        </div>
                        
                        <div class="chart-container">
                            <div class="chart-header">
                                <div class="chart-title">Task Distribution</div>
                                <div class="chart-period">By Category</div>
                            </div>
                            <div class="chart-placeholder">
                                Task distribution chart would be displayed here
                            </div>
                        </div>
                    </div>
                    
                    <!-- Settings Panel -->
                    <div class="workspace-panel" id="settings-panel">
                        <div class="settings-section">
                            <h4>Agent Configuration</h4>
                            <div class="settings-option">
                                <div class="settings-label">Active Status</div>
                                <div class="settings-control">
                                    <label class="toggle-switch">
                                        <input type="checkbox" ${agentData.status === 'active' ? 'checked' : ''}>
                                        <span class="toggle-slider"></span>
                                    </label>
                                </div>
                            </div>
                            <div class="settings-option">
                                <div class="settings-label">Response Time</div>
                                <div class="settings-control">
                                    <select class="settings-select">
                                        <option value="fast">Fast (1-2 hours)</option>
                                        <option value="medium" selected>Medium (3-6 hours)</option>
                                        <option value="thorough">Thorough (6-12 hours)</option>
                                    </select>
                                </div>
                            </div>
                            <div class="settings-option">
                                <div class="settings-label">Feedback Detail Level</div>
                                <div class="settings-control">
                                    <select class="settings-select">
                                        <option value="basic">Basic</option>
                                        <option value="standard" selected>Standard</option>
                                        <option value="comprehensive">Comprehensive</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <div class="settings-section">
                            <h4>Notifications</h4>
                            <div class="settings-option">
                                <div class="settings-label">Email Notifications</div>
                                <div class="settings-control">
                                    <label class="toggle-switch">
                                        <input type="checkbox" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                </div>
                            </div>
                            <div class="settings-option">
                                <div class="settings-label">Task Completion Alerts</div>
                                <div class="settings-control">
                                    <label class="toggle-switch">
                                        <input type="checkbox" checked>
                                        <span class="toggle-slider"></span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        // Add event listeners to workspace tabs
        const tabs = workspaceContent.querySelectorAll('.workspace-tab');
        tabs.forEach(tab => {
            tab.addEventListener('click', function() {
                // Remove active class from all tabs
                tabs.forEach(t => t.classList.remove('active'));
                // Add active class to clicked tab
                this.classList.add('active');
                
                // Hide all panels
                const panels = workspaceContent.querySelectorAll('.workspace-panel');
                panels.forEach(panel => panel.classList.remove('active'));
                
                // Show the selected panel
                const panelId = this.getAttribute('data-tab') + '-panel';
                document.getElementById(panelId).classList.add('active');
            });
        });
        
        // Add event listeners to settings toggles
        const toggles = workspaceContent.querySelectorAll('.toggle-switch input');
        toggles.forEach(toggle => {
            toggle.addEventListener('change', function() {
                // In a real implementation, this would update agent settings
                const settingName = this.closest('.settings-option').querySelector('.settings-label').textContent;
                const isEnabled = this.checked;
                
                // Show a message in chat
                const chatMessages = document.querySelector('.chat-messages');
                const messageDiv = document.createElement('div');
                messageDiv.className = 'system-message';
                messageDiv.innerHTML = `<p>Setting "${settingName}" ${isEnabled ? 'enabled' : 'disabled'} for ${agentData.name}</p>`;
                chatMessages.appendChild(messageDiv);
                chatMessages.scrollTop = chatMessages.scrollHeight;
            });
        });
        
        // Add event listeners to settings selects
        const selects = workspaceContent.querySelectorAll('.settings-select');
        selects.forEach(select => {
            select.addEventListener('change', function() {
                // In a real implementation, this would update agent settings
                const settingName = this.closest('.settings-option').querySelector('.settings-label').textContent;
                const selectedValue = this.value;
                
                // Show a message in chat
                const chatMessages = document.querySelector('.chat-messages');
                const messageDiv = document.createElement('div');
                messageDiv.className = 'system-message';
                messageDiv.innerHTML = `<p>Setting "${settingName}" changed to "${selectedValue}" for ${agentData.name}</p>`;
                chatMessages.appendChild(messageDiv);
                chatMessages.scrollTop = chatMessages.scrollHeight;
            });
        });
        
        // Add event listeners to work item action buttons
        const actionButtons = workspaceContent.querySelectorAll('.work-item-actions button');
        actionButtons.forEach(button => {
            button.addEventListener('click', function() {
                const action = this.textContent.trim();
                const workItem = this.closest('.work-item');
                const workTitle = workItem.querySelector('.work-item-title').textContent;
                
                // Show a message in chat
                const chatMessages = document.querySelector('.chat-messages');
                const messageDiv = document.createElement('div');
                messageDiv.className = 'system-message';
                messageDiv.innerHTML = `<p>Action "${action}" requested for "${workTitle}"</p>`;
                chatMessages.appendChild(messageDiv);
                chatMessages.scrollTop = chatMessages.scrollHeight;
            });
        });
    }
    
    // Generate current work items based on agent role
    function generateCurrentWorkItems(agentData) {
        if (agentData.name.includes('Acquisition Editor')) {
            return `
                <div class="work-item">
                    <div class="work-item-header">
                        <div class="work-item-title">Manuscript Evaluation: "The Silent Echo"</div>
                        <div class="work-item-status">In Progress</div>
                    </div>
                    <div class="work-item-details">
                        Evaluating science fiction novel submission for plot structure, character development, and market potential.
                    </div>
                    <div class="work-item-progress">
                        <div class="progress-bar" style="width: 65%"></div>
                    </div>
                    <div class="work-item-actions">
                        <button>View Details</button>
                        <button>Prioritize</button>
                    </div>
                </div>
                <div class="work-item">
                    <div class="work-item-header">
                        <div class="work-item-title">Query Review: "Shadows of Tomorrow"</div>
                        <div class="work-item-status pending">Pending</div>
                    </div>
                    <div class="work-item-details">
                        Reviewing author query letter and sample chapters for potential acquisition.
                    </div>
                    <div class="work-item-progress">
                        <div class="progress-bar" style="width: 10%"></div>
                    </div>
                    <div class="work-item-actions">
                        <button>View Details</button>
                        <button>Start Review</button>
                    </div>
                </div>
            `;
        } else if (agentData.name.includes('Developmental Editor')) {
            return `
                <div class="work-item">
                    <div class="work-item-header">
                        <div class="work-item-title">Developmental Edit: "Beyond the Horizon"</div>
                        <div class="work-item-status">In Progress</div>
                    </div>
                    <div class="work-item-details">
                        Providing substantive feedback on character arcs, plot structure, and thematic elements.
                    </div>
                    <div class="work-item-progress">
                        <div class="progress-bar" style="width: 45%"></div>
                    </div>
                    <div class="work-item-actions">
                        <button>View Manuscript</button>
                        <button>Add Notes</button>
                    </div>
                </div>
                <div class="work-item">
                    <div class="work-item-header">
                        <div class="work-item-title">Revision Review: "The Last Guardian"</div>
                        <div class="work-item-status">In Progress</div>
                    </div>
                    <div class="work-item-details">
                        Reviewing author's revisions based on previous developmental feedback.
                    </div>
                    <div class="work-item-progress">
                        <div class="progress-bar" style="width: 80%"></div>
                    </div>
                    <div class="work-item-actions">
                        <button>View Manuscript</button>
                        <button>Compare Versions</button>
                    </div>
                </div>
            `;
        } else if (agentData.name.includes('Copy Editor')) {
            return `
                <div class="work-item">
                    <div class="work-item-header">
                        <div class="work-item-title">Copy Edit: "Whispers in the Dark"</div>
                        <div class="work-item-status">In Progress</div>
                    </div>
                    <div class="work-item-details">
                        Reviewing for grammar, spelling, punctuation, and consistency issues.
                    </div>
                    <div class="work-item-progress">
                        <div class="progress-bar" style="width: 70%"></div>
                    </div>
                    <div class="work-item-actions">
                        <button>View Manuscript</button>
                        <button>Check Style Guide</button>
                    </div>
                </div>
            `;
        } else if (agentData.name.includes('Publisher')) {
            return `
                <div class="work-item">
                    <div class="work-item-header">
                        <div class="work-item-title">Acquisition Decision: "The Silent Echo"</div>
                        <div class="work-item-status pending">Pending Review</div>
                    </div>
                    <div class="work-item-details">
                        Reviewing acquisition editor's recommendation and market analysis.
                    </div>
                    <div class="work-item-progress">
                        <div class="progress-bar" style="width: 30%"></div>
                    </div>
                    <div class="work-item-actions">
                        <button>View Report</button>
                        <button>Schedule Meeting</button>
                    </div>
                </div>
                <div class="work-item">
                    <div class="work-item-header">
                        <div class="work-item-title">Quarterly Strategy Review</div>
                        <div class="work-item-status">In Progress</div>
                    </div>
                    <div class="work-item-details">
                        Analyzing performance metrics and adjusting acquisition strategy.
                    </div>
                    <div class="work-item-progress">
                        <div class="progress-bar" style="width: 85%"></div>
                    </div>
                    <div class="work-item-actions">
                        <button>View Analytics</button>
                        <button>Draft Report</button>
                    </div>
                </div>
            `;
        } else {
            return `
                <div class="work-item">
                    <div class="work-item-header">
                        <div class="work-item-title">No Current Tasks</div>
                        <div class="work-item-status">Idle</div>
                    </div>
                    <div class="work-item-details">
                        This agent is currently not assigned to any active tasks.
                    </div>
                    <div class="work-item-actions">
                        <button>Assign Task</button>
                    </div>
                </div>
            `;
        }
    }
    
    // Generate history items based on agent role
    function generateHistoryItems(agentData) {
        if (agentData.name.includes('Acquisition Editor')) {
            return `
                <div class="history-item">
                    <div class="history-icon">
                        <i class="fas fa-check"></i>
                    </div>
                    <div class="history-content">
                        <div class="history-title">Completed Manuscript Evaluation: "Echoes of Eternity"</div>
                        <div class="history-details">Recommended for acquisition with minor revisions</div>
                        <div class="history-time">Yesterday, 3:45 PM</div>
                    </div>
                </div>
                <div class="history-item">
                    <div class="history-icon">
                        <i class="fas fa-times"></i>
                    </div>
                    <div class="history-content">
                        <div class="history-title">Rejected Manuscript: "The Lost Key"</div>
                        <div class="history-details">Not suitable for current catalog, provided feedback to author</div>
                        <div class="history-time">Apr 7, 2025, 10:30 AM</div>
                    </div>
                </div>
                <div class="history-item">
                    <div class="history-icon">
                        <i class="fas fa-check"></i>
                    </div>
                    <div class="history-content">
                        <div class="history-title">Completed Manuscript Evaluation: "The Forgotten Path"</div>
                        <div class="history-details">Recommended for acquisition with developmental editing</div>
                        <div class="history-time">Apr 5, 2025, 2:15 PM</div>
                    </div>
                </div>
            `;
        } else if (agentData.name.includes('Developmental Editor')) {
            return `
                <div class="history-item">
                    <div class="history-icon">
                        <i class="fas fa-check"></i>
                    </div>
                    <div class="history-content">
                        <div class="history-title">Completed Developmental Edit: "Starfall"</div>
                        <div class="history-details">Provided comprehensive feedback on character development and plot structure</div>
                        <div class="history-time">Apr 6, 2025, 5:20 PM</div>
                    </div>
                </div>
                <div class="history-item">
                    <div class="history-icon">
                        <i class="fas fa-check"></i>
                    </div>
                    <div class="history-content">
                        <div class="history-title">Completed Revision Review: "The Crystal Key"</div>
                        <div class="history-details">Approved final manuscript after three revision cycles</div>
                        <div class="history-time">Apr 3, 2025, 11:45 AM</div>
                    </div>
                </div>
            `;
        } else {
            return `
                <div class="history-item">
                    <div class="history-icon">
                        <i class="fas fa-check"></i>
                    </div>
                    <div class="history-content">
                        <div class="history-title">Completed Task: Generic Task</div>
                        <div class="history-details">Task details would appear here</div>
                        <div class="history-time">Apr 5, 2025, 9:30 AM</div>
                    </div>
                </div>
                <div class="history-item">
                    <div class="history-icon">
                        <i class="fas fa-check"></i>
                    </div>
                    <div class="history-content">
                        <div class="history-title">Completed Task: Another Task</div>
                        <div class="history-details">More task details would appear here</div>
                        <div class="history-time">Apr 2, 2025, 2:15 PM</div>
                    </div>
                </div>
            `;
        }
    }
    
    // Expose the createAgentWorkspace function to the global scope
    window.createAgentWorkspace = createAgentWorkspace;
    
    // Initialize with default workspace if needed
    const defaultAgentData = {
        name: "No Agent Selected",
        title: "AI Agent",
        description: "Select an agent from the organizational chart to view their workspace.",
        status: "inactive"
    };
    
    // Connect to org-chart.js
    // When an agent is clicked in the org chart, it will call createAgentWorkspace
    // This is already implemented in the org-chart.js file
});
