import docx
import os

def extract_text_from_docx(file_path):
    doc = docx.Document(file_path)
    full_text = []
    
    for para in doc.paragraphs:
        full_text.append(para.text)
    
    return '\n'.join(full_text)

def main():
    input_file = '/home/ubuntu/upload/Digital_Quill_Publishing_Roadmap.docx'
    output_file = '/home/ubuntu/roadmap_analysis/roadmap_content.txt'
    
    text = extract_text_from_docx(input_file)
    
    with open(output_file, 'w') as f:
        f.write(text)
    
    print(f"Extracted content saved to {output_file}")

if __name__ == "__main__":
    main()
