#!/bin/bash
# Digital Quill Publishing - Unix/Linux/Mac Launch Script
# This script launches the Digital Quill Publishing application

# ANSI color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# Print header
print_header() {
    echo -e "${BLUE}${BOLD}=================================================${NC}"
    echo -e "${BLUE}${BOLD}    Digital Quill Publishing - Launch Script     ${NC}"
    echo -e "${BLUE}${BOLD}=================================================${NC}"
    echo ""
}

# Check if virtual environment exists
check_venv() {
    if [ ! -f "venv/bin/activate" ]; then
        echo -e "${RED}ERROR: Virtual environment not found.${NC}"
        echo -e "Please run the installation script first."
        echo ""
        read -p "Press Enter to exit..."
        exit 1
    fi
}

# Activate virtual environment
activate_venv() {
    echo -e "Activating virtual environment..."
    source venv/bin/activate
}

# Check if .env file exists
check_env_file() {
    if [ ! -f ".env" ]; then
        echo -e "${YELLOW}WARNING: .env file not found.${NC}"
        echo -e "You may need to set up your OpenAI API key."
        echo ""
        read -p "Enter your OpenAI API key (or press Enter to skip): " API_KEY
        if [ ! -z "$API_KEY" ]; then
            echo "OPENAI_API_KEY=$API_KEY" > .env
            echo "FLASK_APP=src/web/app.py" >> .env
            echo "FLASK_ENV=development" >> .env
            echo -e "${GREEN}Created .env file with your API key.${NC}"
        fi
    fi
}

# Display menu
display_menu() {
    clear
    print_header
    echo "1. Start Web Application (Flask)"
    echo "2. Start Streamlit Interface"
    echo "3. Run Environment Test"
    echo "4. Edit Configuration"
    echo "5. Exit"
    echo ""
    read -p "Enter your choice (1-5): " CHOICE
    
    case $CHOICE in
        1) start_flask ;;
        2) start_streamlit ;;
        3) run_test ;;
        4) edit_config ;;
        5) exit_app ;;
        *) 
            echo -e "${YELLOW}Invalid choice. Please try again.${NC}"
            sleep 2
            display_menu
            ;;
    esac
}

# Start Flask web application
start_flask() {
    echo ""
    echo -e "${GREEN}Starting Flask Web Application...${NC}"
    echo -e "The application will be available at ${BOLD}http://localhost:5000${NC}"
    echo -e "Press ${BOLD}Ctrl+C${NC} to stop the server."
    echo ""
    python run_flask.py
    read -p "Press Enter to return to menu..."
    display_menu
}

# Start Streamlit interface
start_streamlit() {
    echo ""
    echo -e "${GREEN}Starting Streamlit Interface...${NC}"
    echo -e "This will open in your web browser automatically."
    echo -e "Press ${BOLD}Ctrl+C${NC} to stop the server."
    echo ""
    python run_streamlit.py
    read -p "Press Enter to return to menu..."
    display_menu
}

# Run environment test
run_test() {
    echo ""
    echo -e "${GREEN}Running Environment Test...${NC}"
    echo ""
    python tests/test_environment.py
    echo ""
    read -p "Press Enter to return to menu..."
    display_menu
}

# Edit configuration
edit_config() {
    echo ""
    echo -e "${GREEN}Opening Configuration File...${NC}"
    echo ""
    
    # Detect available editors
    if command -v nano &>/dev/null; then
        nano config/config.json
    elif command -v vim &>/dev/null; then
        vim config/config.json
    elif command -v vi &>/dev/null; then
        vi config/config.json
    else
        echo -e "${YELLOW}No text editor found. Please edit config/config.json manually.${NC}"
        sleep 2
    fi
    
    display_menu
}

# Exit application
exit_app() {
    echo ""
    echo -e "${GREEN}Thank you for using Digital Quill Publishing!${NC}"
    echo ""
    deactivate
    exit 0
}

# Main function
main() {
    print_header
    check_venv
    activate_venv
    check_env_file
    display_menu
}

# Run main function
main
