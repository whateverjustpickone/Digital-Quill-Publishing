#!/usr/bin/env python3
"""
Digital Quill Publishing - Automated Installation Script
This script automates the installation and setup of the Digital Quill Publishing system.
"""

import os
import sys
import subprocess
import platform
import json
import getpass
import time
import shutil
from pathlib import Path

# ANSI color codes for terminal output
class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

def print_header(text):
    """Print a formatted header."""
    print(f"\n{Colors.HEADER}{Colors.BOLD}{'=' * 80}{Colors.ENDC}")
    print(f"{Colors.HEADER}{Colors.BOLD}{text.center(80)}{Colors.ENDC}")
    print(f"{Colors.HEADER}{Colors.BOLD}{'=' * 80}{Colors.ENDC}\n")

def print_step(step_number, text):
    """Print a formatted step."""
    print(f"{Colors.BLUE}{Colors.BOLD}[Step {step_number}] {text}{Colors.ENDC}")

def print_success(text):
    """Print a success message."""
    print(f"{Colors.GREEN}✓ {text}{Colors.ENDC}")

def print_warning(text):
    """Print a warning message."""
    print(f"{Colors.YELLOW}⚠ {text}{Colors.ENDC}")

def print_error(text):
    """Print an error message."""
    print(f"{Colors.RED}✗ {text}{Colors.ENDC}")

def run_command(command, shell=True, check=True):
    """Run a shell command and return the result."""
    try:
        result = subprocess.run(
            command,
            shell=shell,
            check=check,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        return result
    except subprocess.CalledProcessError as e:
        print_error(f"Command failed: {e}")
        print(f"Error output: {e.stderr}")
        return None

def check_python_version():
    """Check if Python version is 3.8 or higher."""
    print_step(1, "Checking Python version")
    
    version = sys.version_info
    if version.major < 3 or (version.major == 3 and version.minor < 8):
        print_error(f"Python 3.8+ is required. You have Python {version.major}.{version.minor}.{version.micro}")
        print("Please install Python 3.8 or higher and try again.")
        return False
    
    print_success(f"Python {version.major}.{version.minor}.{version.micro} detected")
    return True

def create_virtual_environment(project_dir):
    """Create a virtual environment for the project."""
    print_step(2, "Creating virtual environment")
    
    venv_dir = os.path.join(project_dir, "venv")
    
    # Check if venv already exists
    if os.path.exists(venv_dir):
        response = input(f"Virtual environment already exists at {venv_dir}. Recreate? (y/n): ")
        if response.lower() != 'y':
            print_warning("Using existing virtual environment")
            return True
        shutil.rmtree(venv_dir)
    
    # Create venv
    result = run_command(f"{sys.executable} -m venv {venv_dir}")
    if not result:
        print_error("Failed to create virtual environment")
        return False
    
    print_success(f"Virtual environment created at {venv_dir}")
    return True

def get_activate_command(venv_dir):
    """Get the command to activate the virtual environment based on the OS."""
    if platform.system() == "Windows":
        return f"{os.path.join(venv_dir, 'Scripts', 'activate.bat')}"
    else:
        return f"source {os.path.join(venv_dir, 'bin', 'activate')}"

def install_dependencies(project_dir):
    """Install required Python packages."""
    print_step(3, "Installing dependencies")
    
    venv_dir = os.path.join(project_dir, "venv")
    
    # Determine pip command based on OS
    if platform.system() == "Windows":
        pip_cmd = os.path.join(venv_dir, "Scripts", "pip")
    else:
        pip_cmd = os.path.join(venv_dir, "bin", "pip")
    
    # Install required packages
    packages = [
        "openai",
        "python-dotenv",
        "streamlit",
        "langchain",
        "chromadb",
        "tiktoken",
        "flask",
        "flask-wtf",
        "flask-login",
        "pandas",
        "matplotlib"
    ]
    
    print("Installing packages. This may take a few minutes...")
    for package in packages:
        print(f"Installing {package}...")
        result = run_command(f"{pip_cmd} install {package}", check=False)
        if result and result.returncode != 0:
            print_warning(f"Issue installing {package}: {result.stderr}")
        else:
            print_success(f"Installed {package}")
    
    # Save requirements
    run_command(f"{pip_cmd} freeze > {os.path.join(project_dir, 'requirements.txt')}")
    print_success("Dependencies installed and requirements.txt created")
    return True

def setup_project_structure(project_dir):
    """Create the project directory structure."""
    print_step(4, "Setting up project structure")
    
    # Create directories
    directories = [
        "src/agents",
        "src/utils",
        "src/web",
        "config",
        "data",
        "data/manuscripts",
        "tests",
        "docs"
    ]
    
    for directory in directories:
        dir_path = os.path.join(project_dir, directory)
        os.makedirs(dir_path, exist_ok=True)
        print_success(f"Created directory: {directory}")
    
    return True

def create_config_files(project_dir):
    """Create configuration files."""
    print_step(5, "Creating configuration files")
    
    # Create .env file
    env_file = os.path.join(project_dir, ".env")
    if not os.path.exists(env_file):
        api_key = input("Enter your OpenAI API key (press Enter to skip for now): ")
        with open(env_file, "w") as f:
            f.write(f"OPENAI_API_KEY={api_key}\n")
            f.write("FLASK_APP=src/web/app.py\n")
            f.write("FLASK_ENV=development\n")
        print_success("Created .env file")
    else:
        print_warning(".env file already exists, skipping")
    
    # Create config.json
    config_file = os.path.join(project_dir, "config", "config.json")
    if not os.path.exists(config_file):
        config = {
            "ai": {
                "model": "gpt-3.5-turbo",
                "temperature": 0.2,
                "max_tokens": 1000
            },
            "database": {
                "vector_db": "chroma",
                "persist_directory": "data/vector_db"
            },
            "web": {
                "host": "0.0.0.0",
                "port": 5000,
                "debug": True
            }
        }
        with open(config_file, "w") as f:
            json.dump(config, f, indent=2)
        print_success("Created config.json file")
    else:
        print_warning("config.json already exists, skipping")
    
    # Create .gitignore
    gitignore_file = os.path.join(project_dir, ".gitignore")
    if not os.path.exists(gitignore_file):
        with open(gitignore_file, "w") as f:
            f.write("venv/\n")
            f.write("__pycache__/\n")
            f.write("*.pyc\n")
            f.write(".env\n")
            f.write(".DS_Store\n")
            f.write("data/vector_db/\n")
        print_success("Created .gitignore file")
    else:
        print_warning(".gitignore already exists, skipping")
    
    return True

def create_core_files(project_dir):
    """Create core Python files for the project."""
    print_step(6, "Creating core application files")
    
    # Create __init__.py files
    init_files = [
        "src/__init__.py",
        "src/agents/__init__.py",
        "src/utils/__init__.py",
        "src/web/__init__.py",
    ]
    
    for file_path in init_files:
        full_path = os.path.join(project_dir, file_path)
        if not os.path.exists(full_path):
            with open(full_path, "w") as f:
                f.write("# Digital Quill Publishing\n")
            print_success(f"Created {file_path}")
    
    # Create utils.py
    utils_file = os.path.join(project_dir, "src", "utils", "utils.py")
    if not os.path.exists(utils_file):
        with open(utils_file, "w") as f:
            f.write("""# Digital Quill Publishing - Utility Functions

import os
import json
from pathlib import Path

def load_config(config_path=None):
    \"\"\"Load configuration from JSON file.\"\"\"
    if config_path is None:
        config_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 
                                 "config", "config.json")
    
    with open(config_path, 'r') as f:
        return json.load(f)

def get_project_root():
    \"\"\"Get the absolute path to the project root.\"\"\"
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def ensure_dir(directory):
    \"\"\"Ensure a directory exists.\"\"\"
    Path(directory).mkdir(parents=True, exist_ok=True)
""")
        print_success("Created utils.py")
    else:
        print_warning("utils.py already exists, skipping")
    
    # Create acquisition_editor.py
    acquisition_file = os.path.join(project_dir, "src", "agents", "acquisition_editor.py")
    if not os.path.exists(acquisition_file):
        with open(acquisition_file, "w") as f:
            f.write("""# Digital Quill Publishing - Acquisition Editor Agent

import os
import sys
import openai
from dotenv import load_dotenv

# Add project root to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

# Load environment variables
load_dotenv()

# Configure OpenAI
openai.api_key = os.getenv("OPENAI_API_KEY")

def evaluate_manuscript(manuscript_text):
    \"\"\"
    Evaluate a manuscript using OpenAI.
    
    Args:
        manuscript_text (str): The text of the manuscript to evaluate.
        
    Returns:
        str: The evaluation results.
    \"\"\"
    prompt = f\"\"\"
    You are an experienced Acquisition Editor at Digital Quill Publishing.
    
    Please evaluate the following manuscript excerpt:
    
    {manuscript_text}
    
    Evaluate based on:
    1. Writing Quality (1-10)
    2. Plot and Structure (1-10)
    3. Character Development (1-10)
    4. Market Potential (1-10)
    5. Uniqueness (1-10)
    
    For each criterion, provide a score and brief justification.
    Then provide an overall recommendation: Reject, Revise and Resubmit, or Accept.
    \"\"\"
    
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are an AI assistant that evaluates manuscripts."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.2,
            max_tokens=1000
        )
        
        return response.choices[0].message.content
    except Exception as e:
        return f"Error evaluating manuscript: {str(e)}"

# Example usage
if __name__ == "__main__":
    # Sample manuscript excerpt
    sample_text = \"\"\"
    The old house stood at the end of the lane, its windows dark and shutters hanging loose.
    Sarah approached cautiously, her heart pounding in her chest. The key felt cold in her hand.
    "It's just an old house," she whispered to herself, but the words provided little comfort.
    As she inserted the key into the lock, a strange sound came from inside.
    \"\"\"
    
    # Evaluate the manuscript
    evaluation = evaluate_manuscript(sample_text)
    print("\\n=== MANUSCRIPT EVALUATION ===\\n")
    print(evaluation)
""")
        print_success("Created acquisition_editor.py")
    else:
        print_warning("acquisition_editor.py already exists, skipping")
    
    # Create app.py
    app_file = os.path.join(project_dir, "src", "web", "app.py")
    if not os.path.exists(app_file):
        with open(app_file, "w") as f:
            f.write("""# Digital Quill Publishing - Web Application

import os
import sys
from flask import Flask, render_template, request, redirect, url_for, flash
from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileRequired, FileAllowed
from wtforms import StringField, TextAreaField, SelectField, SubmitField
from wtforms.validators import DataRequired, Length
from werkzeug.utils import secure_filename
from dotenv import load_dotenv

# Add project root to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

# Import project modules
from src.agents.acquisition_editor import evaluate_manuscript
from src.utils.utils import ensure_dir, get_project_root

# Load environment variables
load_dotenv()

# Initialize Flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'dev-key-change-in-production')
app.config['UPLOAD_FOLDER'] = os.path.join(get_project_root(), 'data', 'manuscripts')

# Ensure upload directory exists
ensure_dir(app.config['UPLOAD_FOLDER'])

# Define forms
class SubmissionForm(FlaskForm):
    title = StringField('Title', validators=[DataRequired()])
    author = StringField('Author', validators=[DataRequired()])
    genre = SelectField('Genre', choices=[
        ('fantasy', 'Fantasy'),
        ('sci_fi', 'Science Fiction'),
        ('mystery', 'Mystery/Thriller'),
        ('romance', 'Romance'),
        ('literary', 'Literary Fiction'),
        ('non_fiction', 'Non-Fiction')
    ])
    synopsis = TextAreaField('Synopsis', validators=[DataRequired(), Length(max=500)])
    manuscript = FileField('Manuscript', validators=[
        FileRequired(),
        FileAllowed(['txt', 'doc', 'docx', 'pdf'], 'Text files only!')
    ])
    submit = SubmitField('Submit')

# Routes
@app.route('/')
def home():
    return render_template('home.html')

@app.route('/submit', methods=['GET', 'POST'])
def submit_manuscript():
    form = SubmissionForm()
    
    if form.validate_on_submit():
        # Save manuscript file
        manuscript_file = form.manuscript.data
        filename = secure_filename(manuscript_file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        manuscript_file.save(filepath)
        
        # Read manuscript content (assuming text file)
        if filename.endswith('.txt'):
            with open(filepath, 'r', encoding='utf-8') as f:
                manuscript_text = f.read()
                
            # Get evaluation
            evaluation = evaluate_manuscript(manuscript_text[:4000])  # Limit to first 4000 chars
            
            return render_template('evaluation.html', 
                                  title=form.title.data,
                                  author=form.author.data,
                                  evaluation=evaluation)
        else:
            flash('Only .txt files can be evaluated automatically at this time.')
            return redirect(url_for('submit_manuscript'))
    
    return render_template('submit.html', form=form)

if __name__ == '__main__':
    app.run(debug=True)
""")
        print_success("Created app.py")
    else:
        print_warning("app.py already exists, skipping")
    
    # Create streamlit_app.py
    streamlit_file = os.path.join(project_dir, "streamlit_app.py")
    if not os.path.exists(streamlit_file):
        with open(streamlit_file, "w") as f:
            f.write("""# Digital Quill Publishing - Streamlit Interface

import os
import sys
import streamlit as st
from dotenv import load_dotenv

# Add project root to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Import project modules
from src.agents.acquisition_editor import evaluate_manuscript

# Load environment variables
load_dotenv()

# Streamlit interface
st.set_page_config(
    page_title="Digital Quill Publishing",
    page_icon="📚",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.title("Digital Quill Publishing - Acquisition Editor AI")

st.write(\"\"\"
This tool evaluates manuscript excerpts and provides editorial feedback.
Enter a portion of your manuscript below to receive an evaluation.
\"\"\")

# Sidebar
st.sidebar.header("About Digital Quill Publishing")
st.sidebar.write(\"\"\"
Digital Quill Publishing is an AI-powered virtual publishing house that helps authors
improve their manuscripts and navigate the publishing process.
\"\"\")

st.sidebar.header("How It Works")
st.sidebar.write(\"\"\"
1. Enter a manuscript excerpt (up to 4000 characters)
2. Click "Evaluate Manuscript"
3. Receive detailed feedback from our AI Acquisition Editor
\"\"\")

# Main content
manuscript = st.text_area("Manuscript Excerpt", height=300,
                         placeholder="Paste your manuscript excerpt here...")

if st.button("Evaluate Manuscript"):
    if manuscript:
        with st.spinner("Evaluating manuscript..."):
            evaluation = evaluate_manuscript(manuscript[:4000])  # Limit to first 4000 chars
            st.subheader("Evaluation Results")
            st.write(evaluation)
    else:
        st.error("Please enter a manuscript excerpt to evaluate.")

# Footer
st.markdown("---")
st.markdown("© 2025 Digital Quill Publishing")
""")
        print_success("Created streamlit_app.py")
    else:
        print_warning("streamlit_app.py already exists, skipping")
    
    return True

def create_templates(project_dir):
    """Create HTML templates for the Flask app."""
    print_step(7, "Creating HTML templates")
    
    # Create templates directory
    templates_dir = os.path.join(project_dir, "src", "web", "templates")
    os.makedirs(templates_dir, exist_ok=True)
    
    # Create base.html
    base_html = os.path.join(templates_dir, "base.html")
    if not os.path.exists(base_html):
        with open(base_html, "w") as f:
            f.write("""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{% block title %}Digital Quill Publishing{% endblock %}</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background-color: #f8f9fa;
        }
        .navbar {
            background-color: #1a237e;
        }
        .navbar-brand {
            font-weight: bold;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        .footer {
            margin-top: 50px;
            padding: 20px 0;
            background-color: #f1f1f1;
            text-align: center;
        }
        .card {
            margin-bottom: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .evaluation-section {
            background-color: #f9f9f9;
            padding: 20px;
            border-radius: 5px;
            border-left: 4px solid #1a237e;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="{{ url_for('home') }}">Digital Quill Publishing</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="{{ url_for('home') }}">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ url_for('submit_manuscript') }}">Submit Manuscript</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        {% with messages = get_flashed_messages() %}
            {% if messages %}
                {% for message in messages %}
                    <div class="alert alert-info">{{ message }}</div>
                {% endfor %}
            {% endif %}
        {% endwith %}
        
        {% block content %}{% endblock %}
    </div>

    <footer class="footer">
        <div class="container">
            <p>&copy; 2025 Digital Quill Publishing. All rights reserved.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>""")
        print_success("Created base.html")
    else:
        print_warning("base.html already exists, skipping")
    
    # Create home.html
    home_html = os.path.join(templates_dir, "home.html")
    if not os.path.exists(home_html):
        with open(home_html, "w") as f:
            f.write("""{% extends "base.html" %}

{% block title %}Home - Digital Quill Publishing{% endblock %}

{% block content %}
<div class="row">
    <div class="col-md-8">
        <h1>Welcome to Digital Quill Publishing</h1>
        <p class="lead">
            An AI-powered virtual publishing house that helps authors improve their manuscripts
            and navigate the publishing process.
        </p>
        
        <div class="card mt-4">
            <div class="card-body">
                <h2 class="card-title">How It Works</h2>
                <p class="card-text">
                    Digital Quill Publishing uses artificial intelligence to provide professional-quality
                    feedback on your manuscript. Our AI agents perform the roles traditionally handled by
                    human editors, marketers, and production staff.
                </p>
                <ol>
                    <li>Submit your manuscript for evaluation</li>
                    <li>Receive detailed feedback from our AI Acquisition Editor</li>
                    <li>Get suggestions for improving your manuscript</li>
                    <li>Revise and resubmit for further evaluation</li>
                </ol>
                <a href="{{ url_for('submit_manuscript') }}" class="btn btn-primary">Submit Your Manuscript</a>
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h3 class="card-title mb-0">Our AI Agents</h3>
            </div>
            <div class="card-body">
                <ul class="list-group list-group-flush">
                    <li class="list-group-item">
                        <strong>Acquisition Editor</strong>
                        <p>Evaluates commercial potential and overall quality</p>
                    </li>
                    <li class="list-group-item">
                        <strong>Developmental Editor</strong>
                        <p>Provides feedback on plot, characters, and writing</p>
                    </li>
                    <li class="list-group-item">
                        <strong>Copy Editor</strong>
                        <p>Checks grammar, style, and consistency</p>
                    </li>
                    <li class="list-group-item">
                        <strong>Marketing Strategist</strong>
                        <p>Suggests marketing approaches and target audiences</p>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
{% endblock %}""")
        print_success("Created home.html")
    else:
        print_warning("home.html already exists, skipping")
    
    # Create submit.html
    submit_html = os.path.join(templates_dir, "submit.html")
    if not os.path.exists(submit_html):
        with open(submit_html, "w") as f:
            f.write("""{% extends "base.html" %}

{% block title %}Submit Manuscript - Digital Quill Publishing{% endblock %}

{% block content %}
<h1>Submit Your Manuscript</h1>
<p class="lead">
    Fill out the form below to submit your manuscript for evaluation by our AI Acquisition Editor.
</p>

<div class="card">
    <div class="card-body">
        <form method="POST" enctype="multipart/form-data">
            {{ form.hidden_tag() }}
            
            <div class="mb-3">
                <label for="title" class="form-label">Manuscript Title</label>
                {{ form.title(class="form-control") }}
            </div>
            
            <div class="mb-3">
                <label for="author" class="form-label">Author Name</label>
                {{ form.author(class="form-control") }}
            </div>
            
            <div class="mb-3">
                <label for="genre" class="form-label">Genre</label>
                {{ form.genre(class="form-select") }}
            </div>
            
            <div class="mb-3">
                <label for="synopsis" class="form-label">Synopsis (max 500 words)</label>
                {{ form.synopsis(class="form-control", rows=5) }}
            </div>
            
            <div class="mb-3">
                <label for="manuscript" class="form-label">Upload Manuscript (TXT, DOC, DOCX, or PDF)</label>
                {{ form.manuscript(class="form-control") }}
                <div class="form-text">
                    Note: Only .txt files can be evaluated automatically at this time.
                </div>
            </div>
            
            <div class="d-grid gap-2">
                {{ form.submit(class="btn btn-primary btn-lg") }}
            </div>
        </form>
    </div>
</div>
{% endblock %}""")
        print_success("Created submit.html")
    else:
        print_warning("submit.html already exists, skipping")
    
    # Create evaluation.html
    evaluation_html = os.path.join(templates_dir, "evaluation.html")
    if not os.path.exists(evaluation_html):
        with open(evaluation_html, "w") as f:
            f.write("""{% extends "base.html" %}

{% block title %}Manuscript Evaluation - Digital Quill Publishing{% endblock %}

{% block content %}
<h1>Manuscript Evaluation</h1>
<h2>{{ title }} by {{ author }}</h2>

<div class="evaluation-section">
    <h3>Acquisition Editor Feedback</h3>
    <div class="evaluation-content">
        {{ evaluation | nl2br }}
    </div>
</div>

<div class="d-grid gap-2 col-md-6 mx-auto">
    <a href="{{ url_for('submit_manuscript') }}" class="btn btn-primary">Submit Another Manuscript</a>
    <a href="{{ url_for('home') }}" class="btn btn-secondary">Return to Home</a>
</div>
{% endblock %}""")
        print_success("Created evaluation.html")
    else:
        print_warning("evaluation.html already exists, skipping")
    
    return True

def create_launch_scripts(project_dir):
    """Create launch scripts for the application."""
    print_step(8, "Creating launch scripts")
    
    # Create run_flask.py
    flask_script = os.path.join(project_dir, "run_flask.py")
    if not os.path.exists(flask_script):
        with open(flask_script, "w") as f:
            f.write("""#!/usr/bin/env python3
\"\"\"
Digital Quill Publishing - Flask App Launcher
This script launches the Flask web application.
\"\"\"

import os
import sys
from dotenv import load_dotenv

# Add project root to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Load environment variables
load_dotenv()

# Import Flask app
from src.web.app import app

if __name__ == "__main__":
    # Get port from environment or use default
    port = int(os.getenv("PORT", 5000))
    
    print(f"Starting Digital Quill Publishing Flask app on port {port}...")
    print(f"Access the application at http://localhost:{port}")
    print("Press Ctrl+C to stop the server")
    
    # Run the app
    app.run(host="0.0.0.0", port=port, debug=True)
""")
        print_success("Created run_flask.py")
    else:
        print_warning("run_flask.py already exists, skipping")
    
    # Create run_streamlit.py
    streamlit_script = os.path.join(project_dir, "run_streamlit.py")
    if not os.path.exists(streamlit_script):
        with open(streamlit_script, "w") as f:
            f.write("""#!/usr/bin/env python3
\"\"\"
Digital Quill Publishing - Streamlit App Launcher
This script launches the Streamlit web application.
\"\"\"

import os
import sys
import subprocess

# Get the absolute path to the project directory
project_dir = os.path.dirname(os.path.abspath(__file__))

def main():
    print("Starting Digital Quill Publishing Streamlit app...")
    print("This will open a new browser window automatically.")
    print("Press Ctrl+C to stop the server")
    
    # Run streamlit
    streamlit_app = os.path.join(project_dir, "streamlit_app.py")
    subprocess.run(["streamlit", "run", streamlit_app])

if __name__ == "__main__":
    main()
""")
        print_success("Created run_streamlit.py")
    else:
        print_warning("run_streamlit.py already exists, skipping")
    
    # Create Windows batch files
    if platform.system() == "Windows":
        # Create run_flask.bat
        flask_bat = os.path.join(project_dir, "run_flask.bat")
        if not os.path.exists(flask_bat):
            with open(flask_bat, "w") as f:
                f.write(f"""@echo off
echo Starting Digital Quill Publishing Flask App...
call {os.path.join(project_dir, "venv", "Scripts", "activate.bat")}
python {os.path.join(project_dir, "run_flask.py")}
pause
""")
            print_success("Created run_flask.bat")
        else:
            print_warning("run_flask.bat already exists, skipping")
        
        # Create run_streamlit.bat
        streamlit_bat = os.path.join(project_dir, "run_streamlit.bat")
        if not os.path.exists(streamlit_bat):
            with open(streamlit_bat, "w") as f:
                f.write(f"""@echo off
echo Starting Digital Quill Publishing Streamlit App...
call {os.path.join(project_dir, "venv", "Scripts", "activate.bat")}
python {os.path.join(project_dir, "run_streamlit.py")}
pause
""")
            print_success("Created run_streamlit.bat")
        else:
            print_warning("run_streamlit.bat already exists, skipping")
    
    # Create shell scripts for Unix-like systems
    else:
        # Create run_flask.sh
        flask_sh = os.path.join(project_dir, "run_flask.sh")
        if not os.path.exists(flask_sh):
            with open(flask_sh, "w") as f:
                f.write(f"""#!/bin/bash
echo "Starting Digital Quill Publishing Flask App..."
source {os.path.join(project_dir, "venv", "bin", "activate")}
python {os.path.join(project_dir, "run_flask.py")}
""")
            os.chmod(flask_sh, 0o755)  # Make executable
            print_success("Created run_flask.sh")
        else:
            print_warning("run_flask.sh already exists, skipping")
        
        # Create run_streamlit.sh
        streamlit_sh = os.path.join(project_dir, "run_streamlit.sh")
        if not os.path.exists(streamlit_sh):
            with open(streamlit_sh, "w") as f:
                f.write(f"""#!/bin/bash
echo "Starting Digital Quill Publishing Streamlit App..."
source {os.path.join(project_dir, "venv", "bin", "activate")}
python {os.path.join(project_dir, "run_streamlit.py")}
""")
            os.chmod(streamlit_sh, 0o755)  # Make executable
            print_success("Created run_streamlit.sh")
        else:
            print_warning("run_streamlit.sh already exists, skipping")
    
    return True

def create_readme(project_dir):
    """Create README.md file."""
    print_step(9, "Creating documentation")
    
    readme_file = os.path.join(project_dir, "README.md")
    if not os.path.exists(readme_file):
        with open(readme_file, "w") as f:
            f.write("""# Digital Quill Publishing

An AI-powered virtual publishing house that helps authors improve their manuscripts and navigate the publishing process.

## Overview

Digital Quill Publishing uses artificial intelligence to provide professional-quality feedback on manuscripts. The system includes AI agents that perform the roles traditionally handled by human editors, marketers, and production staff.

## Features

- **Manuscript Evaluation**: Get detailed feedback on your manuscript from our AI Acquisition Editor
- **Web Interface**: Submit manuscripts and view evaluations through a user-friendly web interface
- **Streamlit App**: Alternative interface for manuscript evaluation
- **Extensible Architecture**: Easily add new AI agents and features

## Getting Started

### Prerequisites

- Python 3.8 or higher
- OpenAI API key

### Installation

The installation process has been automated. Simply run:

```bash
# On Windows
python install.py

# On macOS/Linux
python3 install.py
```

### Running the Application

#### Flask Web Interface

```bash
# On Windows
run_flask.bat

# On macOS/Linux
./run_flask.sh
```

Then open your browser and navigate to http://localhost:5000

#### Streamlit Interface

```bash
# On Windows
run_streamlit.bat

# On macOS/Linux
./run_streamlit.sh
```

This will automatically open your browser to the Streamlit interface.

## Project Structure

```
digital_quill_publishing/
├── config/                 # Configuration files
├── data/                   # Data storage
│   └── manuscripts/        # Uploaded manuscripts
├── docs/                   # Documentation
├── src/                    # Source code
│   ├── agents/             # AI agent implementations
│   ├── utils/              # Utility functions
│   └── web/                # Web application
│       └── templates/      # HTML templates
├── tests/                  # Test files
├── venv/                   # Virtual environment
├── .env                    # Environment variables
├── README.md               # This file
├── run_flask.py            # Flask app launcher
├── run_streamlit.py        # Streamlit app launcher
└── streamlit_app.py        # Streamlit application
```

## Usage

1. Start the application using one of the launch scripts
2. Navigate to the web interface in your browser
3. Submit a manuscript for evaluation
4. Review the AI-generated feedback

## Extending the System

To add new AI agents or features:

1. Create a new Python file in the appropriate directory (e.g., `src/agents/`)
2. Implement the agent functionality
3. Update the web interface to include the new feature
4. Test thoroughly before deploying

## License

This project is proprietary and confidential. Unauthorized copying, distribution, or use is strictly prohibited.

## Acknowledgments

- OpenAI for providing the AI models
- The LangChain framework for AI application development
- Flask and Streamlit for web interface development
""")
        print_success("Created README.md")
    else:
        print_warning("README.md already exists, skipping")
    
    # Create pre-installation checklist
    checklist_file = os.path.join(project_dir, "PRE_INSTALLATION_CHECKLIST.md")
    if not os.path.exists(checklist_file):
        with open(checklist_file, "w") as f:
            f.write("""# Digital Quill Publishing - Pre-Installation Checklist

Before running the installation script, please ensure you have the following prerequisites in place:

## System Requirements

- [ ] Operating System: Windows 10/11, macOS 10.15+, or Linux (Ubuntu 20.04+ recommended)
- [ ] Disk Space: At least 1GB of free disk space
- [ ] Memory: Minimum 4GB RAM (8GB+ recommended)
- [ ] Internet Connection: Required for downloading dependencies and API access

## Software Prerequisites

- [ ] Python 3.8 or higher installed
  - Verify with: `python --version` or `python3 --version`
  - If not installed, download from [python.org](https://www.python.org/downloads/)

- [ ] Pip (Python package manager) installed
  - Verify with: `pip --version` or `pip3 --version`
  - Usually included with Python installation

- [ ] Git installed (optional, for version control)
  - Verify with: `git --version`
  - If not installed, download from [git-scm.com](https://git-scm.com/downloads)

## API Access

- [ ] OpenAI API key obtained
  - Sign up at [platform.openai.com](https://platform.openai.com/)
  - Create an API key in your account dashboard
  - Have the API key ready for the installation process

## Installation Environment

- [ ] Administrator/sudo access (for installing system dependencies)
- [ ] Firewall/antivirus configured to allow Python to access the internet
- [ ] Terminal or Command Prompt access

## Optional Requirements

- [ ] Code editor installed (VS Code, PyCharm, etc.)
- [ ] Web browser: Chrome, Firefox, or Edge (latest version)

## Next Steps

Once you have checked all the above requirements, you can proceed with the installation by running:

```bash
# On Windows
python install.py

# On macOS/Linux
python3 install.py
```

The installation script will guide you through the rest of the process.
""")
        print_success("Created PRE_INSTALLATION_CHECKLIST.md")
    else:
        print_warning("PRE_INSTALLATION_CHECKLIST.md already exists, skipping")
    
    return True

def create_test_files(project_dir):
    """Create test files."""
    print_step(10, "Creating test files")
    
    # Create test_environment.py
    test_env_file = os.path.join(project_dir, "tests", "test_environment.py")
    if not os.path.exists(test_env_file):
        with open(test_env_file, "w") as f:
            f.write("""#!/usr/bin/env python3
\"\"\"
Digital Quill Publishing - Environment Test
This script tests that the environment is correctly set up.
\"\"\"

import os
import sys
import importlib.util

# Add project root to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def test_environment_setup():
    \"\"\"Test that the environment is correctly set up.\"\"\"
    print("Testing environment setup...")
    
    # Check Python version
    python_version = sys.version_info
    print(f"Python version: {python_version.major}.{python_version.minor}.{python_version.micro}")
    assert python_version.major == 3 and python_version.minor >= 8, "Python 3.8+ is required"
    
    # Check required packages
    required_packages = [
        "openai",
        "dotenv",
        "streamlit",
        "flask",
        "langchain"
    ]
    
    for package in required_packages:
        try:
            spec = importlib.util.find_spec(package)
            if spec is None:
                print(f"❌ Package {package} is not installed")
                continue
            print(f"✅ Package {package} is installed")
        except ImportError:
            print(f"❌ Package {package} is not installed")
    
    # Check for .env file
    env_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".env")
    if os.path.exists(env_path):
        print("✅ .env file exists")
    else:
        print("❌ .env file does not exist")
    
    print("Environment test completed.")

if __name__ == "__main__":
    test_environment_setup()
""")
        print_success("Created test_environment.py")
    else:
        print_warning("test_environment.py already exists, skipping")
    
    # Create test_acquisition_editor.py
    test_acq_file = os.path.join(project_dir, "tests", "test_acquisition_editor.py")
    if not os.path.exists(test_acq_file):
        with open(test_acq_file, "w") as f:
            f.write("""#!/usr/bin/env python3
\"\"\"
Digital Quill Publishing - Acquisition Editor Test
This script tests the Acquisition Editor agent.
\"\"\"

import os
import sys
import unittest
from unittest.mock import patch, MagicMock

# Add project root to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import the module to test
from src.agents.acquisition_editor import evaluate_manuscript

class TestAcquisitionEditor(unittest.TestCase):
    \"\"\"Test cases for the Acquisition Editor agent.\"\"\"
    
    def setUp(self):
        \"\"\"Set up test fixtures.\"\"\"
        self.test_manuscript = \"\"\"
        The old house stood at the end of the lane, its windows dark and shutters hanging loose.
        Sarah approached cautiously, her heart pounding in her chest. The key felt cold in her hand.
        "It's just an old house," she whispered to herself, but the words provided little comfort.
        As she inserted the key into the lock, a strange sound came from inside.
        \"\"\"
    
    @patch('openai.ChatCompletion.create')
    def test_evaluate_manuscript(self, mock_create):
        \"\"\"Test that evaluate_manuscript calls the OpenAI API correctly.\"\"\"
        # Mock the OpenAI API response
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message = MagicMock()
        mock_response.choices[0].message.content = "Test evaluation"
        mock_create.return_value = mock_response
        
        # Call the function
        result = evaluate_manuscript(self.test_manuscript)
        
        # Check that the API was called with the correct arguments
        mock_create.assert_called_once()
        args, kwargs = mock_create.call_args
        self.assertEqual(kwargs['model'], "gpt-3.5-turbo")
        self.assertEqual(len(kwargs['messages']), 2)
        self.assertEqual(kwargs['messages'][0]['role'], "system")
        self.assertEqual(kwargs['messages'][1]['role'], "user")
        self.assertIn(self.test_manuscript, kwargs['messages'][1]['content'])
        
        # Check the result
        self.assertEqual(result, "Test evaluation")
    
    def test_evaluate_manuscript_error_handling(self):
        \"\"\"Test that evaluate_manuscript handles errors gracefully.\"\"\"
        # Test with an empty manuscript
        result = evaluate_manuscript("")
        self.assertIn("Error", result)

if __name__ == "__main__":
    unittest.main()
""")
        print_success("Created test_acquisition_editor.py")
    else:
        print_warning("test_acquisition_editor.py already exists, skipping")
    
    return True

def finalize_installation(project_dir):
    """Finalize the installation and print summary."""
    print_step(11, "Finalizing installation")
    
    # Create a sample manuscript
    sample_dir = os.path.join(project_dir, "data", "manuscripts")
    sample_file = os.path.join(sample_dir, "sample_manuscript.txt")
    if not os.path.exists(sample_file):
        with open(sample_file, "w") as f:
            f.write("""Title: The Haunting of Willow Creek Manor
Author: Sample Author

Chapter 1

The old house stood at the end of the lane, its windows dark and shutters hanging loose. Willow Creek Manor had been abandoned for decades, or so the locals said. But Sarah Jenkins knew better. She had seen the lights flickering in the upstairs window, late at night when the rest of the town was asleep.

Sarah approached cautiously, her heart pounding in her chest. The key felt cold in her hand. It had arrived in a plain envelope last week, along with a letter from a lawyer she'd never heard of, informing her that she had inherited the property from a great-aunt she didn't know existed.

"It's just an old house," she whispered to herself, but the words provided little comfort. As she inserted the key into the lock, a strange sound came from inside. Not quite a voice, but not quite the settling of an old building either.

The door swung open with a creak that seemed to echo through the empty hallway. Dust motes danced in the beam of sunlight that cut through the gloom. Sarah stepped inside, her footsteps leaving prints in the thick layer of dust on the hardwood floor.

"Hello?" she called out, feeling foolish. No one had lived here for years. There would be no answer.

But there was. A soft thump from upstairs, like a book falling from a shelf. Sarah froze, her breath catching in her throat. She should leave, call the police, report an intruder. That would be the sensible thing to do.

Instead, she found herself climbing the stairs, drawn upward by a curiosity she couldn't explain. The staircase groaned under her weight, announcing her presence to whoever—or whatever—waited above.

The upstairs hallway stretched before her, lined with closed doors. But one stood slightly ajar, a sliver of pale light spilling out onto the faded carpet. Sarah moved toward it, her hand outstretched.

"I've been waiting for you," said a voice from inside the room. It was soft, feminine, and somehow familiar, though Sarah was certain she had never heard it before.

She pushed the door open.
""")
        print_success("Created sample manuscript")
    else:
        print_warning("Sample manuscript already exists, skipping")
    
    # Print installation summary
    print_header("Installation Complete!")
    print(f"Digital Quill Publishing has been installed to: {project_dir}")
    print("\nTo start the application, run one of the following:")
    
    if platform.system() == "Windows":
        print(f"\n  {Colors.GREEN}Windows (Flask Web App):{Colors.ENDC}")
        print(f"  {os.path.join(project_dir, 'run_flask.bat')}")
        print(f"\n  {Colors.GREEN}Windows (Streamlit App):{Colors.ENDC}")
        print(f"  {os.path.join(project_dir, 'run_streamlit.bat')}")
    else:
        print(f"\n  {Colors.GREEN}Unix/Linux/Mac (Flask Web App):{Colors.ENDC}")
        print(f"  {os.path.join(project_dir, 'run_flask.sh')}")
        print(f"\n  {Colors.GREEN}Unix/Linux/Mac (Streamlit App):{Colors.ENDC}")
        print(f"  {os.path.join(project_dir, 'run_streamlit.sh')}")
    
    print(f"\n{Colors.YELLOW}Important Notes:{Colors.ENDC}")
    print("1. Make sure your OpenAI API key is set in the .env file")
    print("2. The Flask app will be available at http://localhost:5000")
    print("3. The Streamlit app will open automatically in your browser")
    print(f"4. A sample manuscript is available at {sample_file}")
    print("5. Refer to the README.md file for more information")
    
    return True

def main():
    """Main installation function."""
    print_header("Digital Quill Publishing - Automated Installation")
    
    # Get installation directory
    default_dir = os.path.join(os.path.expanduser("~"), "digital_quill_publishing")
    project_dir = input(f"Enter installation directory [default: {default_dir}]: ").strip()
    if not project_dir:
        project_dir = default_dir
    
    # Create project directory if it doesn't exist
    os.makedirs(project_dir, exist_ok=True)
    print_success(f"Project directory: {project_dir}")
    
    # Run installation steps
    if not check_python_version():
        return
    
    if not create_virtual_environment(project_dir):
        return
    
    if not setup_project_structure(project_dir):
        return
    
    if not install_dependencies(project_dir):
        return
    
    if not create_config_files(project_dir):
        return
    
    if not create_core_files(project_dir):
        return
    
    if not create_templates(project_dir):
        return
    
    if not create_launch_scripts(project_dir):
        return
    
    if not create_readme(project_dir):
        return
    
    if not create_test_files(project_dir):
        return
    
    if not finalize_installation(project_dir):
        return

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nInstallation cancelled by user.")
        sys.exit(1)
    except Exception as e:
        print_error(f"An error occurred during installation: {str(e)}")
        sys.exit(1)
