# Digital Quill Publishing - Automation Package

This package contains everything you need to set up and run Digital Quill Publishing, an AI-powered virtual publishing house system.

## Contents

- `install.py` - Python installation script
- `install.sh` - Unix/Linux/Mac installation wrapper script
- `launch.bat` - Windows launch menu script
- `launch.sh` - Unix/Linux/Mac launch menu script
- `config_template.json` - Configuration template
- `PRE_INSTALLATION_CHECKLIST.md` - Pre-installation requirements

## Quick Start Guide

### Before Installation

1. Review the `PRE_INSTALLATION_CHECKLIST.md` file to ensure your system meets all requirements
2. Obtain an OpenAI API key from [platform.openai.com](https://platform.openai.com/)

### Installation

#### Windows:
1. Open Command Prompt
2. Navigate to this folder
3. Run: `python install.py`

#### macOS/Linux:
1. Open Terminal
2. Navigate to this folder
3. Run: `chmod +x install.sh` (if not already executable)
4. Run: `./install.sh`

### After Installation

1. Launch the application using:
   - Windows: `launch.bat`
   - macOS/Linux: `./launch.sh`
2. Select the interface you want to use (Flask web app or Streamlit)
3. Begin evaluating manuscripts with AI

## Support

If you encounter any issues during installation or use:

1. Check that all prerequisites are met
2. Verify your OpenAI API key is valid and properly configured
3. Run the environment test from the launch menu
4. Refer to the documentation in the installed application

## About Digital Quill Publishing

Digital Quill Publishing is an AI-powered virtual publishing house that helps authors improve their manuscripts and navigate the publishing process. The system includes AI agents that perform the roles traditionally handled by human editors, marketers, and production staff.
