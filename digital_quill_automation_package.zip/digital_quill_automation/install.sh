#!/bin/bash
# Digital Quill Publishing - Unix/Linux/Mac Installation Wrapper
# This script provides a simple wrapper for the Python installation script

# ANSI color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# Print header
echo -e "${BLUE}${BOLD}=================================================${NC}"
echo -e "${BLUE}${BOLD}    Digital Quill Publishing - Installation       ${NC}"
echo -e "${BLUE}${BOLD}=================================================${NC}"
echo ""

# Check if Python is installed
echo -e "${BOLD}Checking prerequisites...${NC}"
if command -v python3 &>/dev/null; then
    PYTHON_CMD="python3"
    echo -e "${GREEN}✓ Python 3 found${NC}"
elif command -v python &>/dev/null; then
    PYTHON_CMD="python"
    echo -e "${GREEN}✓ Python found${NC}"
else
    echo -e "${RED}✗ Python not found. Please install Python 3.8 or higher.${NC}"
    echo -e "${YELLOW}Visit https://www.python.org/downloads/ to download and install Python.${NC}"
    exit 1
fi

# Check Python version
PYTHON_VERSION=$($PYTHON_CMD -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
PYTHON_MAJOR=$(echo $PYTHON_VERSION | cut -d. -f1)
PYTHON_MINOR=$(echo $PYTHON_VERSION | cut -d. -f2)

echo -e "Python version: ${PYTHON_VERSION}"

if [ "$PYTHON_MAJOR" -lt 3 ] || ([ "$PYTHON_MAJOR" -eq 3 ] && [ "$PYTHON_MINOR" -lt 8 ]); then
    echo -e "${RED}✗ Python 3.8 or higher is required. You have Python ${PYTHON_VERSION}.${NC}"
    echo -e "${YELLOW}Please upgrade Python or install a newer version.${NC}"
    exit 1
else
    echo -e "${GREEN}✓ Python version is compatible${NC}"
fi

# Run the installation script
echo ""
echo -e "${BOLD}Starting Digital Quill Publishing installation...${NC}"
echo ""

$PYTHON_CMD install.py

# Check if installation was successful
if [ $? -eq 0 ]; then
    echo ""
    echo -e "${GREEN}${BOLD}Installation completed successfully!${NC}"
    echo ""
    echo -e "Thank you for installing Digital Quill Publishing."
    echo -e "If you have any questions or need assistance, please refer to the documentation."
else
    echo ""
    echo -e "${RED}${BOLD}Installation encountered an error.${NC}"
    echo -e "Please check the error messages above and try again."
    echo -e "If you need assistance, please contact support."
fi

echo ""
echo -e "${BLUE}${BOLD}=================================================${NC}"
echo ""
