// Authentication check script
function checkAuthentication() {
    const isAuthenticated = sessionStorage.getItem('vphouse_authenticated');
    if (isAuthenticated !== 'true') {
        window.location.href = 'login.html';
    }
}

// Run authentication check when page loads
checkAuthentication();
